/**
 * Express Server for Nihiltheism Architect v1.0
 * Handles all REST API routes, SQLite interactions, background research loops,
 * file ingestion, exports, and mounts Vite middleware.
 */

import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { getDb } from './server/db';
import { seedDatabase } from './server/seedData';
import {
  ingestDocument,
  searchPassages,
  getPassageWithContext,
  performAudit,
  createResearchJob,
  runResearchLoopStep,
  getFullExportBundle,
  generateManuscriptMarkdown,
  createExportZip,
  getHypermapHierarchy,
  getHypermapStats,
  addHypermapNode,
  updateHypermapNode,
  deleteHypermapNode,
  densifyHypermapNode
} from './server/services';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Configure JSON and text limits for large document and PDF base64 payloads
  app.use(express.json({ limit: '60mb' }));
  app.use(express.urlencoded({ extended: true, limit: '60mb' }));

  // Initialize DB and run initial seed if required
  const db = getDb();
  seedDatabase(db);

  // -------------------------------------------------------------------------
  // REST API ROUTES
  // -------------------------------------------------------------------------

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      mode: 'Nihiltheism Architect v1.0',
      database: 'connected',
      timestamp: new Date().toISOString()
    });
  });

  // Project Info
  app.get('/api/project', (req: Request, res: Response) => {
    try {
      const project = db.prepare('SELECT * FROM projects LIMIT 1').get() as any;
      if (!project) return res.status(404).json({ error: 'No project found' });

      const counts = {
        sources: (db.prepare('SELECT COUNT(*) as count FROM sources WHERE project_id = ?').get(project.id) as any).count,
        passages: (db.prepare('SELECT COUNT(*) as count FROM passages p JOIN sources s ON p.source_id = s.id WHERE s.project_id = ?').get(project.id) as any).count,
        concepts: (db.prepare('SELECT COUNT(*) as count FROM concepts WHERE project_id = ?').get(project.id) as any).count,
        claims: (db.prepare('SELECT COUNT(*) as count FROM claims WHERE project_id = ?').get(project.id) as any).count,
        objections: (db.prepare('SELECT COUNT(*) as count FROM objections WHERE project_id = ?').get(project.id) as any).count,
        contradictions: (db.prepare('SELECT COUNT(*) as count FROM contradictions WHERE project_id = ?').get(project.id) as any).count,
        revisions: (db.prepare('SELECT COUNT(*) as count FROM revisions WHERE project_id = ?').get(project.id) as any).count,
        corrections: (db.prepare('SELECT COUNT(*) as count FROM corrections').get() as any).count,
      };

      res.json({ project, counts });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // System Stats (for DashboardView & UI metrics)
  app.get('/api/stats', (req: Request, res: Response) => {
    try {
      const sourcesCount = (db.prepare('SELECT COUNT(*) as count FROM sources').get() as any)?.count || 0;
      const passagesCount = (db.prepare('SELECT COUNT(*) as count FROM passages').get() as any)?.count || 0;
      const conceptsCount = (db.prepare('SELECT COUNT(*) as count FROM concepts').get() as any)?.count || 0;
      const claimsCount = (db.prepare('SELECT COUNT(*) as count FROM claims').get() as any)?.count || 0;
      const correctionsCount = (db.prepare('SELECT COUNT(*) as count FROM corrections').get() as any)?.count || 0;
      const objectionsCount = (db.prepare('SELECT COUNT(*) as count FROM objections').get() as any)?.count || 0;
      const contradictionsCount = (db.prepare('SELECT COUNT(*) as count FROM contradictions').get() as any)?.count || 0;
      const researchJobsCount = (db.prepare('SELECT COUNT(*) as count FROM research_jobs').get() as any)?.count || 0;
      const chaptersCount = (db.prepare('SELECT COUNT(*) as count FROM manuscript_sections').get() as any)?.count || 0;

      const wordsRow = db.prepare('SELECT SUM(word_count) as totalWords FROM manuscript_sections').get() as any;
      const totalWords = wordsRow?.totalWords || 0;

      res.json({
        sources: sourcesCount,
        passages: passagesCount,
        concepts: conceptsCount,
        claims: claimsCount,
        corrections: correctionsCount,
        objections: objectionsCount,
        contradictions: contradictionsCount,
        researchJobs: researchJobsCount,
        manuscriptChapters: chaptersCount,
        totalManuscriptWords: totalWords
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Sources & Ingestion
  app.get('/api/sources', (req: Request, res: Response) => {
    try {
      const sources = db.prepare('SELECT * FROM sources ORDER BY import_timestamp DESC').all();
      res.json(sources.map((s: any) => ({
        ...s,
        extraction_warnings: JSON.parse(s.extraction_warnings || '[]')
      })));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/sources/ingest', async (req: Request, res: Response) => {
    try {
      const { projectId, filename, mediaType, contentBase64, contentText, customMetadata } = req.body;
      if (!filename || (!contentBase64 && !contentText)) {
        return res.status(400).json({ error: 'filename and content (base64 or text) are required.' });
      }

      const projId = projectId || 'proj_journal314_canonical';
      const result = await ingestDocument({
        projectId: projId,
        filename,
        mediaType: mediaType || 'text/plain',
        contentBase64,
        contentText,
        customMetadata
      });

      res.status(201).json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Search Passages (FTS5)
  app.get('/api/passages/search', (req: Request, res: Response) => {
    try {
      const q = (req.query.q as string) || '';
      const sourceId = req.query.source_id as string | undefined;
      const limit = parseInt(req.query.limit as string, 10) || 50;

      const results = searchPassages(q, sourceId, limit);
      res.json(results);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Single Passage with Context Viewer
  app.get('/api/passages/:id', (req: Request, res: Response) => {
    try {
      const context = getPassageWithContext(req.params.id);
      if (!context) return res.status(404).json({ error: 'Passage not found' });
      res.json(context);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Concepts CRUD
  app.get('/api/concepts', (req: Request, res: Response) => {
    try {
      const concepts = db.prepare('SELECT * FROM concepts ORDER BY canonical_term ASC').all();
      res.json(concepts.map((c: any) => ({
        ...c,
        senses: JSON.parse(c.senses || '[]'),
        tags: JSON.parse(c.tags || '[]')
      })));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/concepts', (req: Request, res: Response) => {
    try {
      const { name, canonical_term, definition, senses, thesis, limit_condition, status, tags } = req.body;
      const id = 'c_' + (canonical_term || name || '').toLowerCase().replace(/[^\w]/g, '_').slice(0, 20) + '_' + Date.now().toString().slice(-4);
      const now = new Date().toISOString();

      const insert = db.prepare(`
        INSERT INTO concepts (id, project_id, name, canonical_term, definition, senses, thesis, limit_condition, status, tags, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      insert.run(
        id,
        'proj_journal314_canonical',
        name,
        canonical_term,
        definition,
        JSON.stringify(senses || []),
        thesis || null,
        limit_condition || null,
        status || 'STATED',
        JSON.stringify(tags || []),
        now,
        now
      );

      res.status(201).json({ id, name, canonical_term, definition });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Claims CRUD
  app.get('/api/claims', (req: Request, res: Response) => {
    try {
      const claims = db.prepare('SELECT * FROM claims ORDER BY created_at DESC').all();
      res.json(claims.map((cl: any) => ({
        ...cl,
        source_attributions: JSON.parse(cl.source_attributions || '[]'),
        premise_claim_ids: JSON.parse(cl.premise_claim_ids || '[]'),
        objection_ids: JSON.parse(cl.objection_ids || '[]')
      })));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/claims', (req: Request, res: Response) => {
    try {
      const {
        text,
        claim_type,
        fidelity_label,
        source_attributions,
        premise_claim_ids,
        concise_inference_summary,
        warrant_category,
        support_status,
        objection_ids
      } = req.body;

      const id = 'clm_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6);
      const now = new Date().toISOString();

      const insert = db.prepare(`
        INSERT INTO claims (id, project_id, text, claim_type, fidelity_label, source_attributions, premise_claim_ids, concise_inference_summary, warrant_category, support_status, objection_ids, revision_status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insert.run(
        id,
        'proj_journal314_canonical',
        text,
        claim_type || 'phenomenological_description',
        fidelity_label || 'STATED',
        JSON.stringify(source_attributions || []),
        JSON.stringify(premise_claim_ids || []),
        concise_inference_summary || null,
        warrant_category || 'W1',
        support_status || 'supported',
        JSON.stringify(objection_ids || []),
        'current',
        now,
        now
      );

      res.status(201).json({ id, text, warrant_category });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Objections
  app.get('/api/objections', (req: Request, res: Response) => {
    try {
      const objections = db.prepare('SELECT * FROM objections ORDER BY created_at DESC').all();
      res.json(objections);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/objections', (req: Request, res: Response) => {
    try {
      const { claim_id, title, counter_argument, rival_model, severity, status, reply } = req.body;
      const id = 'obj_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6);
      const now = new Date().toISOString();

      const insert = db.prepare(`
        INSERT INTO objections (id, project_id, claim_id, title, counter_argument, rival_model, severity, status, reply, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      insert.run(
        id,
        'proj_journal314_canonical',
        claim_id,
        title,
        counter_argument,
        rival_model,
        severity || 'serious',
        status || 'addressed',
        reply || null,
        now
      );

      // Link objection to claim if exists
      const claim = db.prepare('SELECT objection_ids FROM claims WHERE id = ?').get(claim_id) as any;
      if (claim) {
        let objs: string[] = [];
        try { objs = JSON.parse(claim.objection_ids || '[]'); } catch {}
        if (!objs.includes(id)) {
          objs.push(id);
          db.prepare('UPDATE claims SET objection_ids = ? WHERE id = ?').run(JSON.stringify(objs), claim_id);
        }
      }

      res.status(201).json({ id, title, rival_model });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Relations
  app.get('/api/relations', (req: Request, res: Response) => {
    try {
      const relations = db.prepare('SELECT * FROM relations').all();
      res.json(relations);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Contradictions
  app.get('/api/contradictions', (req: Request, res: Response) => {
    try {
      const contradictions = db.prepare('SELECT * FROM contradictions').all();
      res.json(contradictions);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Mandatory Critical Revisions (CR-01 through CR-12)
  app.get('/api/corrections', (req: Request, res: Response) => {
    try {
      const corrections = db.prepare('SELECT * FROM corrections ORDER BY code ASC').all();
      res.json(corrections);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Revisions & Review Decisions
  app.get('/api/revisions', (req: Request, res: Response) => {
    try {
      const revisions = db.prepare('SELECT * FROM revisions ORDER BY created_at DESC').all();
      res.json(revisions);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/revisions/:id/decide', (req: Request, res: Response) => {
    try {
      const { decision, reviewer_notes } = req.body;
      const revId = req.params.id;
      const now = new Date().toISOString();

      const updateRev = db.prepare('UPDATE revisions SET status = ? WHERE id = ?');
      updateRev.run(decision, revId);

      const insertDecision = db.prepare(`
        INSERT INTO review_decisions (id, revision_id, decision, reviewer_notes, decided_at)
        VALUES (?, ?, ?, ?, ?)
      `);
      insertDecision.run('dec_' + Date.now().toString(36), revId, decision, reviewer_notes || '', now);

      res.json({ success: true, revision_id: revId, status: decision });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Manuscript Sections
  app.get('/api/manuscript', (req: Request, res: Response) => {
    try {
      const chapters = db.prepare('SELECT * FROM manuscript_sections ORDER BY chapter_number ASC').all();
      res.json(chapters.map((ch: any) => ({
        ...ch,
        cross_references: JSON.parse(ch.cross_references || '[]'),
        open_questions: JSON.parse(ch.open_questions || '[]')
      })));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/manuscript/:num', (req: Request, res: Response) => {
    try {
      const chapter = db.prepare('SELECT * FROM manuscript_sections WHERE chapter_number = ?').get(req.params.num) as any;
      if (!chapter) return res.status(404).json({ error: 'Chapter not found' });
      res.json({
        ...chapter,
        cross_references: JSON.parse(chapter.cross_references || '[]'),
        open_questions: JSON.parse(chapter.open_questions || '[]')
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Full Citation & Constitutional Audit
  app.get('/api/audit', (req: Request, res: Response) => {
    try {
      const report = performAudit();
      res.json(report);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Research Loop Jobs
  app.get('/api/jobs', (req: Request, res: Response) => {
    try {
      const jobs = db.prepare('SELECT * FROM research_jobs ORDER BY created_at DESC').all();
      res.json(jobs.map((j: any) => ({
        ...j,
        target_nodes: JSON.parse(j.target_nodes || '[]')
      })));
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/jobs/:id', (req: Request, res: Response) => {
    try {
      const job = db.prepare('SELECT * FROM research_jobs WHERE id = ?').get(req.params.id) as any;
      if (!job) return res.status(404).json({ error: 'Job not found' });
      const events = db.prepare('SELECT * FROM job_events WHERE job_id = ? ORDER BY timestamp ASC').all(req.params.id);
      res.json({
        ...job,
        target_nodes: JSON.parse(job.target_nodes || '[]'),
        events: events.map((e: any) => ({
          ...e,
          payload: e.payload ? JSON.parse(e.payload) : null
        }))
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/jobs/run', async (req: Request, res: Response) => {
    try {
      const { focus_area, max_claims } = req.body;
      const initialClaims = (db.prepare('SELECT COUNT(*) as count FROM claims').get() as any)?.count || 0;
      const initialObjections = (db.prepare('SELECT COUNT(*) as count FROM objections').get() as any)?.count || 0;

      let job = db.prepare('SELECT * FROM research_jobs WHERE status IN ("queued", "running") ORDER BY created_at DESC LIMIT 1').get() as any;
      let jobId: string;
      if (!job) {
        jobId = await createResearchJob(
          'proj_journal314_canonical',
          [focus_area || 'all_passages'],
          3,
          36
        );
      } else {
        jobId = job.id;
      }

      const updatedJob = await runResearchLoopStep(jobId);

      const finalClaims = (db.prepare('SELECT COUNT(*) as count FROM claims').get() as any)?.count || 0;
      const finalObjections = (db.prepare('SELECT COUNT(*) as count FROM objections').get() as any)?.count || 0;

      res.json({
        job: {
          ...updatedJob,
          target_nodes: typeof updatedJob.target_nodes === 'string' ? JSON.parse(updatedJob.target_nodes || '[]') : updatedJob.target_nodes,
          cycles_completed: updatedJob.current_cycle,
          total_tokens: (updatedJob.requests_executed || 1) * 720,
          summary: `Bounded Cycle ${updatedJob.current_cycle}/${updatedJob.max_cycles} completed with PEC-Ω warrant validation.`
        },
        newClaimsCount: Math.max(0, finalClaims - initialClaims),
        newObjectionsCount: Math.max(0, finalObjections - initialObjections)
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/research/jobs', async (req: Request, res: Response) => {
    try {
      const { targetNodes, maxCycles, maxRequests } = req.body;
      const jobId = await createResearchJob(
        'proj_journal314_canonical',
        targetNodes || ['all_passages'],
        maxCycles || 3,
        maxRequests || 36
      );
      res.status(201).json({ jobId, status: 'queued' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/research/jobs/:id', (req: Request, res: Response) => {
    try {
      const job = db.prepare('SELECT * FROM research_jobs WHERE id = ?').get(req.params.id) as any;
      if (!job) return res.status(404).json({ error: 'Job not found' });
      const events = db.prepare('SELECT * FROM job_events WHERE job_id = ? ORDER BY timestamp ASC').all(req.params.id);
      res.json({
        ...job,
        target_nodes: JSON.parse(job.target_nodes || '[]'),
        events: events.map((e: any) => ({
          ...e,
          payload: e.payload ? JSON.parse(e.payload) : null
        }))
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/research/jobs/:id/step', async (req: Request, res: Response) => {
    try {
      const updatedJob = await runResearchLoopStep(req.params.id);
      res.json(updatedJob);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Hypermap Dialectic Matrix Routes
  app.get('/api/hypermap/tree', (req: Request, res: Response) => {
    try {
      const root = req.query.root as string | undefined;
      const hierarchy = getHypermapHierarchy(root);
      res.json(hierarchy);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/hypermap/stats', (req: Request, res: Response) => {
    try {
      const stats = getHypermapStats();
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/hypermap/node/:id', (req: Request, res: Response) => {
    try {
      const node = db.prepare('SELECT * FROM hypermap_nodes WHERE id = ?').get(req.params.id);
      if (!node) return res.status(404).json({ error: 'Hypermap node not found' });
      res.json(node);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/hypermap/node', (req: Request, res: Response) => {
    try {
      const { parent_id, root_tree_id, title, node_type, warrant_category, payload_text, epistemic_status, paradox_relation, fidelity_label } = req.body;
      if (!parent_id || !title || !payload_text) {
        return res.status(400).json({ error: 'parent_id, title, and payload_text are required.' });
      }

      const newNode = addHypermapNode({
        parent_id,
        root_tree_id,
        title,
        node_type: node_type || 'claim',
        warrant_category,
        payload_text,
        epistemic_status,
        paradox_relation,
        fidelity_label
      });

      res.status(201).json(newNode);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/hypermap/node/:id', (req: Request, res: Response) => {
    try {
      const updated = updateHypermapNode(req.params.id, req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/hypermap/node/:id', (req: Request, res: Response) => {
    try {
      const result = deleteHypermapNode(req.params.id);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/hypermap/densify', async (req: Request, res: Response) => {
    try {
      const { nodeId, strategy } = req.body;
      if (!nodeId) {
        return res.status(400).json({ error: 'nodeId is required for densification.' });
      }

      const result = await densifyHypermapNode(nodeId, strategy);
      res.json(result);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Exports
  app.get('/api/export/bundle', (req: Request, res: Response) => {
    try {
      const bundle = getFullExportBundle();
      res.json(bundle);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/export/markdown', (req: Request, res: Response) => {
    try {
      const chapters = db.prepare('SELECT * FROM manuscript_sections ORDER BY chapter_number ASC').all() as any[];
      const markdown = generateManuscriptMarkdown(chapters);
      res.setHeader('Content-Type', 'text/markdown');
      res.setHeader('Content-Disposition', 'attachment; filename="nihiltheism_reference_edition_v1.0.md"');
      res.send(markdown);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/export/zip', async (req: Request, res: Response) => {
    try {
      const zipBuffer = await createExportZip();
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="nihiltheism_architect_release_archive.zip"');
      res.send(zipBuffer);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Explicit 404 handler for any unhandled /api routes to prevent falling through to Vite SPA HTML fallback
  app.all('/api/*', (req: Request, res: Response) => {
    res.status(404).json({ error: `API endpoint not found: ${req.method} ${req.originalUrl}` });
  });

  // -------------------------------------------------------------------------
  // VITE MIDDLEWARE SETUP
  // -------------------------------------------------------------------------

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n======================================================`);
    console.log(` NIHILTHEISM ARCHITECT v1.0 running on http://0.0.0.0:${PORT}`);
    console.log(` SQLite Database: Connected (WAL Mode + FTS5)`);
    console.log(` Reference Edition: 17 Chapters Seeded`);
    console.log(` Constitutional Status: PEC-Ω Active`);
    console.log(`======================================================\n`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
