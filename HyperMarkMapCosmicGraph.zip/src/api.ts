import type {
  Source,
  Passage,
  Concept,
  Claim,
  MandatoryCorrection,
  AdversarialObjection,
  Contradiction,
  ManuscriptSection,
  ResearchJob,
  AuditReport,
  FullExportBundle,
  HypermapNode,
  HypermapTreeNode,
  HypermapNodeInput,
  HypermapStats,
  HypermapDensifyResult
} from './types';

export interface StatsResponse {
  sources: number;
  passages: number;
  concepts: number;
  claims: number;
  corrections: number;
  objections: number;
  contradictions: number;
  researchJobs: number;
  manuscriptChapters: number;
  totalManuscriptWords: number;
}

export interface PassageContextResponse {
  passage: Passage;
  prevPassage: Passage | null;
  nextPassage: Passage | null;
  source: Source | null;
}

async function handleResponse<T>(res: Response): Promise<T> {
  const contentType = res.headers.get('content-type') || '';
  if (!res.ok) {
    let errMsg = `Request failed: ${res.status} ${res.statusText}`;
    try {
      if (contentType.includes('application/json')) {
        const data = await res.json();
        if (data.error) errMsg = data.error;
      } else {
        const text = await res.text();
        if (text && !text.trim().startsWith('<') && text.length < 200) {
          errMsg = text;
        }
      }
    } catch {
      // fallback
    }
    throw new Error(errMsg);
  }

  if (!contentType.includes('application/json')) {
    const text = await res.text();
    if (text.trim().startsWith('<')) {
      throw new Error(`Server returned HTML instead of JSON for API request: ${res.url}`);
    }
    try {
      return JSON.parse(text) as T;
    } catch {
      throw new Error(`Failed to parse response as JSON: ${text.slice(0, 100)}`);
    }
  }

  return res.json() as Promise<T>;
}

export const api = {
  getStats: async (): Promise<StatsResponse> => {
    const res = await fetch('/api/stats');
    return handleResponse<StatsResponse>(res);
  },

  getSources: async (): Promise<Source[]> => {
    const res = await fetch('/api/sources');
    return handleResponse<Source[]>(res);
  },

  ingestText: async (filename: string, text: string): Promise<Source> => {
    const res = await fetch('/api/sources/ingest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename, text })
    });
    return handleResponse<Source>(res);
  },

  searchPassages: async (query: string, limit: number = 25): Promise<Passage[]> => {
    const res = await fetch(`/api/passages/search?q=${encodeURIComponent(query)}&limit=${limit}`);
    return handleResponse<Passage[]>(res);
  },

  getPassageContext: async (id: string): Promise<PassageContextResponse> => {
    const res = await fetch(`/api/passages/${encodeURIComponent(id)}`);
    return handleResponse<PassageContextResponse>(res);
  },

  getCorrections: async (): Promise<MandatoryCorrection[]> => {
    const res = await fetch('/api/corrections');
    return handleResponse<MandatoryCorrection[]>(res);
  },

  getClaims: async (): Promise<Claim[]> => {
    const res = await fetch('/api/claims');
    return handleResponse<Claim[]>(res);
  },

  createClaim: async (claim: Partial<Claim>): Promise<Claim> => {
    const res = await fetch('/api/claims', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(claim)
    });
    return handleResponse<Claim>(res);
  },

  getObjections: async (): Promise<AdversarialObjection[]> => {
    const res = await fetch('/api/objections');
    return handleResponse<AdversarialObjection[]>(res);
  },

  createObjection: async (objection: Partial<AdversarialObjection>): Promise<AdversarialObjection> => {
    const res = await fetch('/api/objections', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(objection)
    });
    return handleResponse<AdversarialObjection>(res);
  },

  getContradictions: async (): Promise<Contradiction[]> => {
    const res = await fetch('/api/contradictions');
    return handleResponse<Contradiction[]>(res);
  },

  getManuscriptChapters: async (): Promise<ManuscriptSection[]> => {
    const res = await fetch('/api/manuscript');
    return handleResponse<ManuscriptSection[]>(res);
  },

  getManuscriptChapter: async (num: number): Promise<ManuscriptSection> => {
    const res = await fetch(`/api/manuscript/${num}`);
    return handleResponse<ManuscriptSection>(res);
  },

  getJobs: async (): Promise<ResearchJob[]> => {
    const res = await fetch('/api/jobs');
    return handleResponse<ResearchJob[]>(res);
  },

  runResearchLoopStep: async (focusArea?: string, maxClaims?: number): Promise<{ job: ResearchJob; newClaimsCount: number; newObjectionsCount: number }> => {
    const res = await fetch('/api/jobs/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ focus_area: focusArea, max_claims: maxClaims })
    });
    return handleResponse<{ job: ResearchJob; newClaimsCount: number; newObjectionsCount: number }>(res);
  },

  runAudit: async (): Promise<AuditReport> => {
    const res = await fetch('/api/audit');
    return handleResponse<AuditReport>(res);
  },

  getHypermapTree: async (root?: string): Promise<HypermapTreeNode> => {
    const query = root ? `?root=${encodeURIComponent(root)}` : '';
    const res = await fetch(`/api/hypermap/tree${query}`);
    return handleResponse<HypermapTreeNode>(res);
  },

  getHypermapStats: async (): Promise<HypermapStats> => {
    const res = await fetch('/api/hypermap/stats');
    return handleResponse<HypermapStats>(res);
  },

  getHypermapNode: async (id: string): Promise<HypermapNode> => {
    const res = await fetch(`/api/hypermap/node/${encodeURIComponent(id)}`);
    return handleResponse<HypermapNode>(res);
  },

  addHypermapNode: async (input: HypermapNodeInput): Promise<HypermapNode> => {
    const res = await fetch('/api/hypermap/node', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input)
    });
    return handleResponse<HypermapNode>(res);
  },

  updateHypermapNode: async (id: string, updates: Partial<HypermapNodeInput>): Promise<HypermapNode> => {
    const res = await fetch(`/api/hypermap/node/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    return handleResponse<HypermapNode>(res);
  },

  deleteHypermapNode: async (id: string): Promise<{ success: boolean; deletedCount: number }> => {
    const res = await fetch(`/api/hypermap/node/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return handleResponse<{ success: boolean; deletedCount: number }>(res);
  },

  densifyHypermapNode: async (nodeId: string, strategy?: string): Promise<HypermapDensifyResult> => {
    const res = await fetch('/api/hypermap/densify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nodeId, strategy })
    });
    return handleResponse<HypermapDensifyResult>(res);
  },

  getExportBundleUrl: (): string => '/api/export/bundle',
  getExportZipUrl: (): string => '/api/export/zip'
};
