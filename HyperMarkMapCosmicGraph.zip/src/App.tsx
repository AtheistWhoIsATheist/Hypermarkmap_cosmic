import React from 'react';
import { GroundedEpistemicTopology } from './components/GroundedEpistemicTopology';

export default function App() {
  return (
    <main className="w-screen h-screen overflow-hidden bg-black select-none">
      <GroundedEpistemicTopology />
    </main>
  );
}
