import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import App from './App';
import { parseMarkdownFile } from './lib/ingestion/astStripper';
import { parsePlaintextFile } from './lib/ingestion/heuristicNormalizer';
import { parsePDFFile } from './lib/ingestion/pdfStreamReader';
import { processBatchFiles } from './lib/ingestion/batchProcessor';
import { exportToMarkdown, exportToPlainText } from './lib/exportEngine';
import { usePKMStore } from './store/pkmStore';
import { useGraphStore } from './store/graphStore';

describe('Nihiltheism Knowledge System (NKS)', () => {
  it('renders the PKM dashboard and core navigation', () => {
    render(<App />);
    expect(screen.getAllByText(/Nihiltheism/i).length).toBeGreaterThan(0);
    expect(screen.getByText('PKM Engine')).toBeInTheDocument();
  });

  it('correctly parses markdown AST with frontmatter and ontological relations', () => {
    const sampleMd = `---
title: Speculative Nihilism
project: journal314
tags: [ontology, void]
---

# Speculative Nihilism

[[Sacred Dread]] emerges from [[The Void]] [causes]
[[Apophatic Void]] is synonymous with [[Nihiltheism]] [isA]
`;

    const ast = parseMarkdownFile('speculative_nihilism.md', sampleMd, sampleMd.length, 'journal314');
    expect(ast.title).toBe('Speculative Nihilism');
    expect(ast.projectId).toBe('journal314');
    expect(ast.relations.length).toBe(2);
    expect(ast.relations[0].relationCode).toBe('causes');
    expect(ast.relations[1].relationCode).toBe('isA');
    expect(ast.entities.length).toBeGreaterThanOrEqual(2);
    expect(ast.layoutFidelity).toBe('lossless');
  });

  it('correctly normalizes plaintext with heuristics and entity detection', () => {
    const sampleTxt = `Aphorisms on Negative Ontology

Emil Cioran explores the phenomenology of Despair.
Martin Heidegger observes how Being-toward-death reveals Nothingness.
`;

    const ast = parsePlaintextFile('cioran_aphorisms.txt', sampleTxt, sampleTxt.length, 'ren');
    expect(ast.title).toBe('Aphorisms on Negative Ontology');
    expect(ast.fileType).toBe('txt');
    expect(ast.detectedConcepts.length).toBeGreaterThan(0);
    expect(ast.layoutFidelity).toBe('lossless');
  });

  it('marks PDF extraction with heuristic-approximate layout fidelity', async () => {
    const emptyBuffer = new ArrayBuffer(16);
    try {
      const ast = await parsePDFFile('test_paper.pdf', emptyBuffer, 16, 'general');
      expect(ast.layoutFidelity).toBe('heuristic-approximate');
      expect(ast.layoutWarning).toBeDefined();
    } catch (e: any) {
      expect(e.message).toContain('PDF');
    }
  });

  it('supports partial batch success when processing mixed files', async () => {
    const validMd = new File(['# The Void\n[[The Void]] is absolute [isA]'], 'void.md', { type: 'text/markdown' });
    const unsupported = new File(['bad'], 'bad.txt', { type: 'text/plain' });

    let progressEvents = 0;
    const { nodes, summary } = await processBatchFiles([validMd, unsupported], 'general', () => {
      progressEvents++;
    });

    expect(nodes.length).toBe(2);
    expect(summary.totalFiles).toBe(2);
    expect(summary.processedFiles).toBe(2);
    expect(progressEvents).toBeGreaterThan(0);
  });

  it('synchronizes ingested AST documents into pkmStore and graphStore', () => {
    const sampleMd = `# The Unconditioned\n[[The Void]] manifests as [[Nihiltheism]] [resonatesWith]`;
    const ast = parseMarkdownFile('unconditioned.md', sampleMd, sampleMd.length, 'journal314');

    // Ingest into PKM store
    usePKMStore.getState().addDocument({
      type: 'essay',
      projectId: 'journal314',
      title: ast.title,
      content: ast.rawContent,
      tags: ['nihilism', 'test'],
      detectedConcepts: [...ast.detectedConcepts],
      resonanceScore: ast.resonanceScore,
    });

    const docs = usePKMStore.getState().documents;
    const added = docs.find((d) => d.title === 'The Unconditioned');
    expect(added).toBeDefined();

    // Ingest entities into Graph Store
    useGraphStore.getState().addNode({
      id: 'node-test-void',
      label: 'The Void',
      type: 'pillar',
      definition: 'Absolute ontological groundlessness',
      weight: 10,
      sourceDocId: added?.id || 'doc-1',
      sourceFilename: 'unconditioned.md',
    });

    const node = useGraphStore.getState().nodes.get('node-test-void');
    expect(node).toBeDefined();
    expect(node?.label).toBe('The Void');
  });

  it('exports graph to InfraNodus compatible markdown and plaintext report', () => {
    const nodes = new Map<string, any>([
      ['1', { id: '1', label: 'The Void', type: 'pillar', definition: 'The unconditioned nothingness', weight: 10, sourceDocId: 'doc1', sourceFilename: 'void.md' }],
      ['2', { id: '2', label: 'Sacred Dread', type: 'pillar', definition: 'Numinous anxiety', weight: 9, sourceDocId: 'doc2', sourceFilename: 'dread.md' }]
    ]);
    const edges = new Map<string, any>([
      ['e1', { id: 'e1', source: '1', target: '2', relation: 'causes', dialecticalTension: 0.88, citation: 'Confrontation with void evokes visceral dread.' }]
    ]);

    const md = exportToMarkdown({ nodes, edges });
    expect(md).toContain('**[[The Void]]**');
    expect(md).toContain('**[[Sacred Dread]]**');
    expect(md).toContain('`[causes]`');

    const txt = exportToPlainText({ nodes, edges });
    expect(txt).toContain('NIHILTHEISM KNOWLEDGE SYSTEM');
    expect(txt).toContain('CAUSES');
  });
});
