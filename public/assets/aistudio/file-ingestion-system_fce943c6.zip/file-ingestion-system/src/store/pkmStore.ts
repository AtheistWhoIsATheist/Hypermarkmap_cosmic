import { create } from 'zustand';
import { PKMDocument, Connection, KnowledgeGap, SearchQuery } from '../lib/types';
import { CanonicalASTNode } from '../lib/ingestion/types';
import { useGraphStore } from './graphStore';

interface PKMState {
  documents: PKMDocument[];
  connections: Connection[];
  gaps: KnowledgeGap[];
  searchHistory: SearchQuery[];

  // Actions
  addDocument: (doc: Omit<PKMDocument, 'id' | 'createdAt' | 'updatedAt'>) => string;
  updateDocument: (id: string, doc: Partial<PKMDocument>) => void;
  deleteDocument: (id: string) => void;
  summarizeDocument: (id: string) => Promise<void>;

  addConnection: (connection: Omit<Connection, 'id'>) => string;
  addKnowledgeGap: (gap: Omit<KnowledgeGap, 'id' | 'createdAt'>) => void;
  logSearch: (query: string) => void;

  // Bulk Ingestion & AST synchronization
  ingestASTNodes: (nodes: CanonicalASTNode[]) => { addedDocs: number; addedConnections: number };
  bulkAddDocuments: (docs: Array<Omit<PKMDocument, 'id' | 'createdAt' | 'updatedAt'>>) => void;

  // Mock initial data load
  initializeMockData: () => void;
}

// Generate simple mock IDs
const genId = () => Math.random().toString(36).substring(2, 9);

export const usePKMStore = create<PKMState>((set, get) => ({
  documents: [],
  connections: [],
  gaps: [],
  searchHistory: [],

  addDocument: (doc) => {
    const id = genId();
    const now = new Date().toISOString();
    const newDoc: PKMDocument = {
      ...doc,
      id,
      createdAt: now,
      updatedAt: now,
    };
    set((state) => ({
      documents: [newDoc, ...state.documents],
    }));

    // Register into graphStore
    useGraphStore.getState().addNode({
      id: newDoc.id,
      label: newDoc.title,
      type: 'concept',
      definition: newDoc.content.slice(0, 300),
      weight: Math.round(((newDoc.resonanceScore || 0.8) * 10)),
      sourceDocId: newDoc.id,
      sourceFilename: `${newDoc.title}.md`,
    });

    return id;
  },

  updateDocument: (id, updates) =>
    set((state) => ({
      documents: state.documents.map((d) =>
        d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d
      ),
    })),

  deleteDocument: (id) =>
    set((state) => ({
      documents: state.documents.filter((d) => d.id !== id),
      // Also remove associated connections
      connections: state.connections.filter((c) => c.sourceId !== id && c.targetId !== id),
    })),

  summarizeDocument: async (id) => {
    const doc = get().documents.find((d) => d.id === id);
    if (!doc) return;

    try {
      const { summarizeText } = await import('../lib/ai');
      const summary = await summarizeText(doc.content);

      set((state) => ({
        documents: state.documents.map((d) =>
          d.id === id ? { ...d, summary, updatedAt: new Date().toISOString() } : d
        ),
      }));
    } catch (err) {
      console.error('Failed to summarize document:', err);
    }
  },

  addConnection: (conn) => {
    const id = genId();
    const newConn = { ...conn, id };
    set((state) => ({
      connections: [...state.connections, newConn],
    }));

    useGraphStore.getState().addEdge({
      id: newConn.id,
      source: conn.sourceId,
      target: conn.targetId,
      relation: 'relatedTo',
      dialecticalTension: 0.85,
      citation: conn.description || 'Interconnected philosophical resonance',
    });

    return id;
  },

  addKnowledgeGap: (gap) =>
    set((state) => ({
      gaps: [{ ...gap, id: genId(), createdAt: new Date().toISOString() }, ...state.gaps],
    })),

  logSearch: (query) =>
    set((state) => ({
      searchHistory: [{ id: genId(), query, timestamp: new Date().toISOString() }, ...state.searchHistory.slice(0, 49)],
    })),

  bulkAddDocuments: (docs) => {
    const now = new Date().toISOString();
    const newDocs: PKMDocument[] = docs.map((d) => ({
      ...d,
      id: genId(),
      createdAt: now,
      updatedAt: now,
    }));

    set((state) => ({
      documents: [...newDocs, ...state.documents],
    }));
  },

  ingestASTNodes: (nodes: CanonicalASTNode[]) => {
    const now = new Date().toISOString();
    const currentDocs = get().documents;
    const currentConnections = get().connections;

    const newDocs: PKMDocument[] = [];
    const newConnections: Connection[] = [];
    const graphNodesToAdd: any[] = [];
    const graphEdgesToAdd: any[] = [];

    // Map AST nodes to PKM Documents
    nodes.forEach((ast) => {
      // Check if document with same title already exists
      const existing = currentDocs.find(
        (d) => d.title.trim().toLowerCase() === ast.title.trim().toLowerCase()
      );

      const docId = existing ? existing.id : genId();
      const tags = ast.frontmatter?.tags ? (Array.isArray(ast.frontmatter.tags) ? ast.frontmatter.tags : [ast.frontmatter.tags]) : [];

      const doc: PKMDocument = {
        id: docId,
        type: ast.fileType === 'md' ? 'essay' : 'note',
        projectId: ast.projectId,
        title: ast.title,
        content: ast.cleanedText || ast.rawContent,
        tags: tags,
        detectedConcepts: [...ast.detectedConcepts],
        resonanceScore: ast.resonanceScore,
        summary: ast.summary || (ast.cleanedText.length > 200 ? ast.cleanedText.substring(0, 200) + '...' : undefined),
        createdAt: now,
        updatedAt: now,
      };

      if (!existing) {
        newDocs.push(doc);
      }

      // Add to graph nodes
      graphNodesToAdd.push({
        id: docId,
        label: doc.title,
        type: (ast.entities[0]?.category || 'concept'),
        definition: doc.content.slice(0, 300),
        weight: Math.min(10, Math.max(3, Math.round(doc.resonanceScore * 10))),
        sourceDocId: docId,
        sourceFilename: ast.fileName,
      });

      // Add concept nodes to graph
      ast.entities.forEach((ent) => {
        const entId = `entity-${ent.name.toLowerCase().replace(/\s+/g, '-')}`;
        graphNodesToAdd.push({
          id: entId,
          label: ent.name,
          type: ent.category,
          definition: `Ontological concept: ${ent.name} [${ent.category}]`,
          weight: Math.min(10, Math.max(3, ent.frequency * 2)),
          sourceDocId: docId,
          sourceFilename: ast.fileName,
        });

        // Edge between document and concept
        graphEdgesToAdd.push({
          id: genId(),
          source: docId,
          target: entId,
          relation: 'containsConcept',
          dialecticalTension: 0.75,
          citation: `Conceptual occurrence in ${ast.fileName}`,
        });
      });

      // Add parsed ontological relations to graph
      ast.relations.forEach((rel) => {
        const sId = `entity-${rel.entity1.toLowerCase().replace(/\s+/g, '-')}`;
        const tId = `entity-${rel.entity2.toLowerCase().replace(/\s+/g, '-')}`;

        graphNodesToAdd.push({
          id: sId,
          label: rel.entity1,
          type: 'concept',
          definition: `Ontological node: ${rel.entity1}`,
          weight: 7,
          sourceDocId: docId,
          sourceFilename: ast.fileName,
        });
        graphNodesToAdd.push({
          id: tId,
          label: rel.entity2,
          type: 'concept',
          definition: `Ontological node: ${rel.entity2}`,
          weight: 7,
          sourceDocId: docId,
          sourceFilename: ast.fileName,
        });

        graphEdgesToAdd.push({
          id: genId(),
          source: sId,
          target: tId,
          relation: rel.relationCode || 'relatedTo',
          dialecticalTension: 0.85,
          citation: rel.rawStatement,
        });
      });
    });

    // Auto-synthesize connections between docs that share detected concepts
    const allCombinedDocs = [...newDocs, ...currentDocs];
    for (let i = 0; i < allCombinedDocs.length; i++) {
      for (let j = i + 1; j < allCombinedDocs.length; j++) {
        const d1 = allCombinedDocs[i];
        const d2 = allCombinedDocs[j];
        const shared = d1.detectedConcepts.filter((c) => d2.detectedConcepts.includes(c));

        if (shared.length > 0) {
          const alreadyConnected = [...currentConnections, ...newConnections].some(
            (c) => (c.sourceId === d1.id && c.targetId === d2.id) || (c.sourceId === d2.id && c.targetId === d1.id)
          );

          if (!alreadyConnected) {
            newConnections.push({
              id: genId(),
              sourceId: d1.id,
              targetId: d2.id,
              description: `Resonant philosophical intersection via: ${shared.slice(0, 3).join(', ')}`,
            });
          }
        }
      }
    }

    // Commit to PKM store
    set((state) => ({
      documents: [...newDocs, ...state.documents],
      connections: [...state.connections, ...newConnections],
    }));

    // Commit to Graph store
    useGraphStore.getState().bulkAddNodesAndEdges(graphNodesToAdd, graphEdgesToAdd);

    return {
      addedDocs: newDocs.length,
      addedConnections: newConnections.length,
    };
  },

  initializeMockData: () =>
    set((state) => {
      if (state.documents.length > 0) return state; // Don't override if already loaded

      const now = new Date().toISOString();
      return {
        documents: [
          {
            id: 'mock-1',
            type: 'note',
            projectId: 'journal314',
            title: 'Initial reading of Cioran',
            content:
              "Cioran's approach to the void is visceral rather than strictly analytical. He does not build a system to contain the void; he allows the void to dismantle the system.",
            detectedConcepts: ['Despair', 'Anti-system', 'The Void'],
            resonanceScore: 0.85,
            createdAt: now,
            updatedAt: now,
          },
          {
            id: 'mock-2',
            type: 'essay',
            projectId: 'ren',
            title: 'The Religious Experience of Nihilism - Draft 1',
            content:
              'Nihilism is typically categorized as an absence of religious experience, but what if the encounter with meaninglessness is structurally identical to the apophatic encounter with God?',
            detectedConcepts: ['Apophatic Theology', 'Structural Identity', 'Meaninglessness'],
            resonanceScore: 0.92,
            createdAt: now,
            updatedAt: now,
          },
        ],
        gaps: [
          {
            id: 'gap-1',
            title: 'The Bridge Between Apophatic Mysticism and Secular Despair',
            description:
              'It is unclear whether the phenomenological state of the mystic entering the "Cloud of Unknowing" is neurologically or psychologically identical to the secular nihilist experiencing profound meaning-collapse, despite similarities in their language.',
            recommendedAuthors: ['St. John of the Cross', 'Emil Cioran', 'Arthur Schopenhauer'],
            recommendedBooks: ['The Dark Night of the Soul', 'The Trouble with Being Born'],
            status: 'open',
            createdAt: now,
          },
        ],
        connections: [
          {
            id: 'conn-1',
            sourceId: 'mock-1',
            targetId: 'mock-2',
            description:
              "Cioran's visceral dismantling of systems acts as a preliminary stage to recognizing the structural identity of nihilism and apophatic theology.",
          },
        ],
      };
    }),
}));
