import { create } from 'zustand';
import { KnowledgeNode, KnowledgeEdge, NodeType } from '../lib/ingestion/types';

interface GraphState {
  nodes: Map<string, KnowledgeNode>;
  edges: Map<string, KnowledgeEdge>;
  addNode: (node: KnowledgeNode) => void;
  addEdge: (edge: KnowledgeEdge) => void;
  bulkAddNodesAndEdges: (newNodes: KnowledgeNode[], newEdges: KnowledgeEdge[]) => void;
  syncFromPKM: (documents: Array<{ id: string; title: string; content: string; detectedConcepts?: string[]; resonanceScore?: number | null }>, connections: Array<{ id: string; sourceId: string; targetId: string; description: string }>) => void;
  clearGraph: () => void;
}

// Initial seed knowledge nodes based on Nihiltheism ontology
const INITIAL_SEEDED_NODES: KnowledgeNode[] = [
  {
    id: 'node-void',
    label: 'The Apophatic Void',
    type: 'pillar',
    definition: 'The Nothingness is not a problem to solve or an absence, but the disclosure of pure unconditioned reality.',
    weight: 10,
    sourceDocId: 'seed-core',
    sourceFilename: 'NKS_Axioms.md',
  },
  {
    id: 'node-dread',
    label: 'Sacred Dread',
    type: 'pillar',
    definition: 'The numinous anxiety that accompanies the dissolution of teleological systems and ego-containment.',
    weight: 9,
    sourceDocId: 'seed-core',
    sourceFilename: 'NKS_Phenomenology.md',
  },
  {
    id: 'node-cioran',
    label: 'Emil Cioran',
    type: 'nihilist',
    definition: 'Radical negative syllogistics; refusing metaphysical consolation while treating existence as a glorious disaster.',
    weight: 9,
    sourceDocId: 'seed-cioran',
    sourceFilename: 'Cioran_Fragments.txt',
  },
  {
    id: 'node-nietzsche',
    label: 'Friedrich Nietzsche',
    type: 'nihilist',
    definition: 'Proclamation of the death of God as historical event requiring active transvaluation of all values.',
    weight: 8,
    sourceDocId: 'seed-nietzsche',
    sourceFilename: 'Gay_Science.txt',
  },
  {
    id: 'node-heidegger',
    label: 'Martin Heidegger',
    type: 'nihilist',
    definition: 'Dasein as Being-toward-death; the confrontation with Nothingness as the ground of ontological disclosure.',
    weight: 8,
    sourceDocId: 'seed-heidegger',
    sourceFilename: 'Sein_und_Zeit.pdf',
  },
  {
    id: 'node-eckhart',
    label: 'Meister Eckhart',
    type: 'mystic',
    definition: 'The Godhead (Gottheit) as unconditioned silent wilderness beyond God (Gott) and all conceptual categories.',
    weight: 9,
    sourceDocId: 'seed-eckhart',
    sourceFilename: 'German_Sermons.md',
  },
  {
    id: 'node-unknowing',
    label: 'Cloud of Unknowing',
    type: 'mystic',
    definition: 'Apophatic protocol: darkness pierced only by a sharp dart of longing love, abandoning intellect.',
    weight: 8,
    sourceDocId: 'seed-mystic',
    sourceFilename: 'Via_Negativa.md',
  },
  {
    id: 'node-aporia-1',
    label: 'Absence as Presence',
    type: 'aporia',
    definition: 'Divine absence constitutes its own radical form of transcendent presence.',
    weight: 10,
    sourceDocId: 'seed-core',
    sourceFilename: 'Dialectical_Tension.md',
  },
  {
    id: 'node-neti',
    label: 'Neti Neti Protocol',
    type: 'concept',
    definition: 'Upanishadic apophatic stripping: Not this, not this, until subject-object collapse is realized.',
    weight: 7,
    sourceDocId: 'seed-core',
    sourceFilename: 'Epistemic_Engines.md',
  },
  {
    id: 'node-coincidentia',
    label: 'Coincidentia Oppositorum',
    type: 'concept',
    definition: 'The structural coincidence of absolute meaninglessness and absolute sacred freedom.',
    weight: 8,
    sourceDocId: 'seed-core',
    sourceFilename: 'Paradox_Engines.md',
  },
];

const INITIAL_SEEDED_EDGES: KnowledgeEdge[] = [
  {
    id: 'edge-1',
    source: 'node-void',
    target: 'node-dread',
    relation: 'causes',
    dialecticalTension: 0.88,
    citation: 'Confrontation with unconditioned void evokes visceral ontological shudder.',
  },
  {
    id: 'edge-2',
    source: 'node-void',
    target: 'node-eckhart',
    relation: 'derivedFrom',
    dialecticalTension: 0.72,
    citation: 'The Gottheit as pure abyss precedes the created deity.',
  },
  {
    id: 'edge-3',
    source: 'node-dread',
    target: 'node-heidegger',
    relation: 'hasAttribute',
    dialecticalTension: 0.81,
    citation: 'Anxiety brings Dasein face to face with its own authentic nothingness.',
  },
  {
    id: 'edge-4',
    source: 'node-cioran',
    target: 'node-dread',
    relation: 'opposes',
    dialecticalTension: 0.94,
    citation: 'Dismantles all systems to allow the void to consume false teleologies.',
  },
  {
    id: 'edge-5',
    source: 'node-nietzsche',
    target: 'node-heidegger',
    relation: 'relatedTo',
    dialecticalTension: 0.75,
    citation: 'Active nihilism transitions into the question of Being.',
  },
  {
    id: 'edge-6',
    source: 'node-eckhart',
    target: 'node-unknowing',
    relation: 'relatedTo',
    dialecticalTension: 0.65,
    citation: 'Medieval apophasis piercing the darkness of conceptual stripping.',
  },
  {
    id: 'edge-7',
    source: 'node-aporia-1',
    target: 'node-void',
    relation: 'isA',
    dialecticalTension: 0.92,
    citation: 'Absence functions as the primary ontological signifier.',
  },
  {
    id: 'edge-8',
    source: 'node-neti',
    target: 'node-unknowing',
    relation: 'relatedTo',
    dialecticalTension: 0.7,
    citation: 'Universal contemplative negation across Western and Eastern traditions.',
  },
];

const createInitialMaps = () => {
  const nodeMap = new Map<string, KnowledgeNode>();
  INITIAL_SEEDED_NODES.forEach((n) => nodeMap.set(n.id, n));

  const edgeMap = new Map<string, KnowledgeEdge>();
  INITIAL_SEEDED_EDGES.forEach((e) => edgeMap.set(e.id, e));

  return { nodeMap, edgeMap };
};

const initialData = createInitialMaps();

export const useGraphStore = create<GraphState>((set) => ({
  nodes: initialData.nodeMap,
  edges: initialData.edgeMap,

  addNode: (node) =>
    set((state) => {
      const next = new Map(state.nodes);
      next.set(node.id, node);
      return { nodes: next };
    }),

  addEdge: (edge) =>
    set((state) => {
      const next = new Map(state.edges);
      next.set(edge.id, edge);
      return { edges: next };
    }),

  bulkAddNodesAndEdges: (newNodes, newEdges) =>
    set((state) => {
      const nextNodes = new Map(state.nodes);
      newNodes.forEach((n) => nextNodes.set(n.id, n));

      const nextEdges = new Map(state.edges);
      newEdges.forEach((e) => nextEdges.set(e.id, e));

      return { nodes: nextNodes, edges: nextEdges };
    }),

  syncFromPKM: (documents, connections) =>
    set((state) => {
      const nextNodes = new Map(state.nodes);
      const nextEdges = new Map(state.edges);

      documents.forEach((d) => {
        let type: NodeType = 'concept';
        const lower = (d.title + ' ' + d.content).toLowerCase();
        if (lower.includes('void') || lower.includes('nothingness') || lower.includes('nihiltheism')) {
          type = 'pillar';
        } else if (lower.includes('cioran') || lower.includes('nietzsche') || lower.includes('despair')) {
          type = 'nihilist';
        } else if (lower.includes('eckhart') || lower.includes('mystic') || lower.includes('godhead')) {
          type = 'mystic';
        }

        const nodeId = d.id;
        if (!nextNodes.has(nodeId)) {
          nextNodes.set(nodeId, {
            id: nodeId,
            label: d.title,
            type,
            definition: d.content.slice(0, 300),
            weight: Math.round(((d.resonanceScore || 0.8) * 10)),
            sourceDocId: d.id,
            sourceFilename: `${d.title}.md`,
          });
        }
      });

      connections.forEach((c) => {
        if (!nextEdges.has(c.id)) {
          nextEdges.set(c.id, {
            id: c.id,
            source: c.sourceId,
            target: c.targetId,
            relation: 'relatedTo',
            dialecticalTension: 0.85,
            citation: c.description || 'Interconnected philosophical resonance',
          });
        }
      });

      return { nodes: nextNodes, edges: nextEdges };
    }),

  clearGraph: () => set({ nodes: new Map(), edges: new Map() }),
}));
