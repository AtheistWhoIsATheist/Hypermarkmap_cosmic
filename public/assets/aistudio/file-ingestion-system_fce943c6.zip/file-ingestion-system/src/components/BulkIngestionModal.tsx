import { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { CanonicalASTNode, IngestionBatchSummary } from '../lib/ingestion/types';
import { processBatchFiles, loadSampleCorpusToAST } from '../lib/ingestion/batchProcessor';
import { usePKMStore } from '../store/pkmStore';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { FILE_INGESTION_SYSTEM_ZIP_BASE64 } from '../constants/zipBase64';
import { 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Cpu, 
  Network, 
  Sparkles, 
  Code2, 
  Layers, 
  BookOpen, 
  Check, 
  Trash2, 
  Eye, 
  ArrowRight,
  FolderOpen,
  Download
} from 'lucide-react';
import { toast } from 'sonner';

interface BulkIngestionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onViewGraph?: () => void;
}

export function BulkIngestionModal({ open, onOpenChange, onViewGraph }: BulkIngestionModalProps) {
  const { ingestASTNodes } = usePKMStore();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStatus, setProgressStatus] = useState('');
  const [astQueue, setAstQueue] = useState<CanonicalASTNode[]>([]);
  const [selectedAST, setSelectedAST] = useState<CanonicalASTNode | null>(null);
  const [targetProject, setTargetProject] = useState<'journal314' | 'ren' | 'general'>('general');
  const [batchSummary, setBatchSummary] = useState<IngestionBatchSummary | null>(null);

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = async (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await handleFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      await handleFiles(Array.from(e.target.files));
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleFiles = async (files: File[]) => {
    setIsProcessing(true);
    setProgress(5);
    setProgressStatus('Initializing Bulk Ingestion Engine...');

    try {
      const { nodes, summary } = await processBatchFiles(
        files,
        targetProject,
        (pct, current, total, msg, latest) => {
          setProgress(pct);
          setProgressStatus(`[${current}/${total}] ${msg}`);
          if (latest) {
            setAstQueue((prev) => [...prev.filter((n) => n.id !== latest.id), latest]);
          }
        }
      );

      setAstQueue((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const newOnes = nodes.filter((n) => !existingIds.has(n.id));
        return [...prev, ...newOnes];
      });

      setBatchSummary(summary);
      setSelectedAST(nodes[0] || null);
      toast.success('Corpus Processed', {
        description: `Successfully generated ${nodes.length} Canonical AST representations.`,
      });
    } catch (err: any) {
      toast.error('Processing Failed', { description: err.message });
    } finally {
      setIsProcessing(false);
      setProgress(100);
      setProgressStatus('Processing complete. Review In-Memory AST.');
    }
  };

  const handleLoadSampleCorpus = () => {
    setIsProcessing(true);
    setProgressStatus('Synthesizing Canonical Nihiltheism Sample Corpus...');
    setProgress(30);

    setTimeout(() => {
      const samples = loadSampleCorpusToAST();
      setAstQueue(samples);
      setSelectedAST(samples[0]);
      setIsProcessing(false);
      setProgress(100);
      setProgressStatus('Sample corpus loaded into In-Memory AST.');
      toast.success('Sample Corpus Loaded', {
        description: 'Loaded 3 benchmark philosophical documents with frontmatter & ontological relations.',
      });
    }, 400);
  };

  const handleCommitToPKM = () => {
    if (astQueue.length === 0) return;

    const validNodes = astQueue.filter((n) => n.status !== 'error');
    const { addedDocs, addedConnections } = ingestASTNodes(validNodes);

    // Update status to committed
    setAstQueue((prev) => prev.map((n) => ({ ...n, status: 'committed' })));

    toast.success('Committed to PKM & Knowledge Graph', {
      description: `Integrated ${addedDocs} documents and synthesized ${addedConnections} inferential links.`,
    });

    if (onViewGraph) {
      setTimeout(() => {
        onOpenChange(false);
        onViewGraph();
      }, 700);
    } else {
      setTimeout(() => onOpenChange(false), 800);
    }
  };

  const handleDownloadZip = (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      // Decode Base64 to ArrayBuffer and trigger explicit Blob download
      const binaryString = atob(FILE_INGESTION_SYSTEM_ZIP_BASE64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/zip' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'file-ingestion-system.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast.success('File Ingestion System Archive Downloaded', {
        description: `Downloaded file-ingestion-system.zip (${(bytes.length / 1024).toFixed(1)} KB, 25 full files).`,
      });
    } catch (err: any) {
      // Fallback to direct anchor link
      const fallbackLink = document.createElement('a');
      fallbackLink.href = '/file-ingestion-system.zip';
      fallbackLink.download = 'file-ingestion-system.zip';
      document.body.appendChild(fallbackLink);
      fallbackLink.click();
      document.body.removeChild(fallbackLink);
    }
  };

  const handleRemoveNode = (id: string) => {
    setAstQueue((prev) => prev.filter((n) => n.id !== id));
    if (selectedAST?.id === id) {
      setSelectedAST(astQueue.find((n) => n.id !== id) || null);
    }
  };

  const handleClearAll = () => {
    setAstQueue([]);
    setSelectedAST(null);
    setBatchSummary(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl h-[88vh] bg-[#07070b]/95 border-white/10 text-foreground p-0 flex flex-col overflow-hidden backdrop-blur-2xl shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-white/5 bg-[#0a0a10]/60 shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="h-8 w-8 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(138,43,226,0.3)]">
                  <Layers className="h-4 w-4" />
                </div>
                <div>
                  <DialogTitle className="text-xl font-serif font-bold tracking-tight text-foreground flex items-center gap-2">
                    Bulk Ingestion & Knowledge Graph Runtime
                    <Badge variant="outline" className="text-[9px] uppercase tracking-widest bg-primary/10 text-primary border-primary/30">
                      Zero-Loss Intermediate AST
                    </Badge>
                  </DialogTitle>
                  <DialogDescription className="text-xs text-muted-foreground mt-0.5">
                    Stream multi-file Markdown, Plaintext, and PDF documents into canonical ontological representations.
                  </DialogDescription>
                </div>
              </div>
            </div>

            {/* Target Project Selector */}
            <div className="flex items-center gap-2 bg-white/5 p-1 rounded-lg border border-white/5">
              <span className="text-[10px] uppercase font-mono tracking-wider text-muted-foreground px-2">Project:</span>
              <button
                onClick={() => setTargetProject('journal314')}
                className={`px-2.5 py-1 text-xs rounded transition-all ${
                  targetProject === 'journal314' ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Journal314
              </button>
              <button
                onClick={() => setTargetProject('ren')}
                className={`px-2.5 py-1 text-xs rounded transition-all ${
                  targetProject === 'ren' ? 'bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                REN
              </button>
              <button
                onClick={() => setTargetProject('general')}
                className={`px-2.5 py-1 text-xs rounded transition-all ${
                  targetProject === 'general' ? 'bg-primary/20 text-primary font-semibold border border-primary/30' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                General
              </button>
            </div>

            {/* Download Full Ingestion System Zip */}
            <button
              onClick={handleDownloadZip}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-medium transition-all shadow-sm cursor-pointer"
              title="Download entire file ingestion system as a zip archive (25 full files)"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download Ingestion System (.zip)</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-white/5">
          {/* Left Column: Dropzone & Queue */}
          <div className="md:col-span-5 p-5 flex flex-col h-full overflow-hidden bg-[#050508]/40">
            {/* Drag & Drop Area */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer flex flex-col items-center justify-center shrink-0 ${
                isDragging
                  ? 'border-primary bg-primary/10 shadow-[0_0_20px_rgba(138,43,226,0.2)]'
                  : 'border-white/10 hover:border-white/20 bg-white/[0.02] hover:bg-white/[0.04]'
              }`}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".md,.markdown,.txt,.pdf"
                className="hidden"
                onChange={handleFileSelect}
              />
              <div className="h-12 w-12 rounded-full bg-white/5 flex items-center justify-center mb-3 text-muted-foreground group-hover:text-primary transition-colors">
                <UploadCloud className="h-6 w-6" />
              </div>
              <p className="text-sm font-medium text-foreground">
                Drop files here or <span className="text-primary underline">browse</span>
              </p>
              <p className="text-[11px] text-muted-foreground/70 mt-1">
                Supports <span className="font-mono text-white/80">.MD</span> (Lossless AST), <span className="font-mono text-white/80">.TXT</span> (Raw Stream), and <span className="font-mono text-white/80">.PDF</span> (Heuristic)
              </p>
            </div>

            {/* Architecture Advisory Notice on PDF Extraction */}
            <div className="mt-2.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300/90 leading-relaxed flex items-start gap-2">
              <span className="text-amber-400 font-bold shrink-0 text-xs">⚠️</span>
              <div>
                <strong className="text-amber-300 font-medium">PDF Extraction Advisory:</strong> PDF extraction uses spatial text-stream reassembly and <em>cannot guarantee lossless layout</em>, multi-column order, or table structure. For canonical lossless fidelity, pre-convert PDFs to Markdown (via <code className="font-mono text-[10px] bg-black/40 px-1 py-0.5 rounded text-amber-200">marker</code>, <code className="font-mono text-[10px] bg-black/40 px-1 py-0.5 rounded text-amber-200">pdftotext</code>, or <code className="font-mono text-[10px] bg-black/40 px-1 py-0.5 rounded text-amber-200">MarkItDown</code>) before ingesting.
              </div>
            </div>

            {/* Quick Action: Load Sample Corpus */}
            <div className="mt-3 flex items-center justify-between text-xs">
              <Button
                variant="outline"
                size="sm"
                onClick={handleLoadSampleCorpus}
                disabled={isProcessing}
                className="w-full h-8 text-[11px] bg-white/5 hover:bg-white/10 border-white/10 text-muted-foreground hover:text-foreground justify-center gap-2"
              >
                <Sparkles className="h-3 w-3 text-amber-400" /> Load Built-in Nihiltheism Corpus (3 Files)
              </Button>
            </div>

            {/* Progress Bar (if processing) */}
            {isProcessing && (
              <div className="mt-4 p-3 rounded-lg bg-primary/10 border border-primary/20 space-y-2">
                <div className="flex justify-between text-[11px] font-mono text-primary">
                  <span className="truncate pr-2">{progressStatus}</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-1.5 bg-black/40" />
              </div>
            )}

            {/* Ingestion Queue */}
            <div className="mt-5 flex-1 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/5">
                <span className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground">
                  AST Pipeline Queue ({astQueue.length})
                </span>
                {astQueue.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={handleClearAll} className="h-6 px-2 text-[10px] text-destructive hover:bg-destructive/10">
                    <Trash2 className="h-3 w-3 mr-1" /> Clear
                  </Button>
                )}
              </div>

              <ScrollArea className="flex-1 pr-2">
                {astQueue.length === 0 ? (
                  <div className="h-36 flex flex-col items-center justify-center text-center p-4 text-muted-foreground/60">
                    <FileText className="h-8 w-8 mb-2 opacity-40" />
                    <p className="text-xs">No documents in ingestion queue.</p>
                    <p className="text-[10px] mt-1 text-muted-foreground/40">Upload files or click "Load Sample Corpus" above.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {astQueue.map((item) => {
                      const isSelected = selectedAST?.id === item.id;
                      return (
                        <div
                          key={item.id}
                          onClick={() => setSelectedAST(item)}
                          className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected
                              ? 'bg-primary/15 border-primary/40 shadow-[0_0_12px_rgba(138,43,226,0.15)]'
                              : 'bg-white/[0.02] hover:bg-white/[0.05] border-white/5'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1">
                            <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-white/10 text-white/90 shrink-0">
                              .{item.fileType}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <p className="text-xs font-medium text-foreground truncate">{item.title}</p>
                                {item.fileType === 'pdf' ? (
                                  <span className="text-[8px] font-mono px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0" title="PDF extraction cannot guarantee lossless layout">
                                    Heuristic
                                  </span>
                                ) : (
                                  <span className="text-[8px] font-mono px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                                    Lossless
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-muted-foreground flex items-center gap-2 mt-0.5">
                                <span>{item.wordCount} words</span>
                                <span>•</span>
                                <span>{item.detectedConcepts.length} concepts</span>
                                <span>•</span>
                                <span className="text-primary font-mono">{(item.resonanceScore * 100).toFixed(0)}% res</span>
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 ml-2">
                            {item.status === 'committed' ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                            ) : item.status === 'error' ? (
                              <AlertCircle className="h-4 w-4 text-destructive" />
                            ) : (
                              <Badge variant="outline" className="text-[9px] border-white/10 bg-white/5">
                                Ready
                              </Badge>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemoveNode(item.id);
                              }}
                              className="h-6 w-6 rounded flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </div>
          </div>

          {/* Right Column: In-Memory AST Inspector */}
          <div className="md:col-span-7 p-6 flex flex-col h-full overflow-hidden bg-[#07070d]/50">
            {selectedAST ? (
              <div className="flex-1 flex flex-col overflow-hidden space-y-4">
                {/* File Header */}
                <div className="flex items-start justify-between pb-3 border-b border-white/5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30">
                        {selectedAST.fileType.toUpperCase()} AST
                      </span>
                      <h3 className="text-base font-serif font-bold text-foreground truncate">{selectedAST.title}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 flex items-center gap-3">
                      <span>Source: <code className="font-mono text-[11px] text-white/80">{selectedAST.fileName}</code></span>
                      <span>Target: <code className="font-mono text-[11px] text-primary">{selectedAST.projectId}</code></span>
                      <span>Resonance: <strong className="text-emerald-400 font-mono">{(selectedAST.resonanceScore * 100).toFixed(0)}%</strong></span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] font-mono border-white/10 bg-white/5">
                      {selectedAST.entities.length} Entities
                    </Badge>
                    <Badge variant="outline" className="text-[10px] font-mono border-white/10 bg-white/5">
                      {selectedAST.relations.length} Relations
                    </Badge>
                  </div>
                </div>

                {/* AST Details Viewer */}
                <ScrollArea className="flex-1 pr-3">
                  <div className="space-y-5">
                    {/* PDF Layout Notice if applicable */}
                    {selectedAST.fileType === 'pdf' && (
                      <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-[11px] uppercase tracking-wider text-amber-400">
                          <span>⚠️ Layout Fidelity Warning (PDF Spatial Reassembly)</span>
                        </div>
                        <p className="text-[11px] text-amber-200/80 leading-relaxed">
                          PDF extraction cannot guarantee lossless layout, multi-column reading order, or table formatting. If source documents contain complex typography or multi-column layouts, convert to Markdown before ingesting (e.g. via <code className="font-mono bg-black/40 px-1 py-0.5 rounded text-amber-100">marker</code> or <code className="font-mono bg-black/40 px-1 py-0.5 rounded text-amber-100">pdftotext</code>).
                        </p>
                      </div>
                    )}

                    {/* Frontmatter (if present) */}
                    {Object.keys(selectedAST.frontmatter).length > 0 && (
                      <div className="p-3.5 rounded-lg bg-white/[0.03] border border-white/5 space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-mono text-muted-foreground uppercase tracking-wider">
                          <span className="flex items-center gap-1.5"><Code2 className="h-3 w-3 text-amber-400" /> Parsed YAML Frontmatter</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                          {Object.entries(selectedAST.frontmatter).map(([k, v]) => (
                            <div key={k} className="bg-black/30 p-2 rounded border border-white/5">
                              <span className="text-muted-foreground">{k}: </span>
                              <span className="text-foreground font-semibold">{Array.isArray(v) ? v.join(', ') : String(v)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Discovered Ontological Relations */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                          <Network className="h-3 w-3 text-accent" /> Extracted Ontological Relations ({selectedAST.relations.length})
                        </span>
                      </div>

                      {selectedAST.relations.length > 0 ? (
                        <div className="space-y-1.5">
                          {selectedAST.relations.map((rel, idx) => (
                            <div key={idx} className="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between text-xs">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-foreground underline decoration-primary/50">[[{rel.entity1}]]</span>
                                <span className="text-muted-foreground text-[11px] italic">{rel.relationDescription}</span>
                                <span className="font-semibold text-foreground underline decoration-accent/50">[[{rel.entity2}]]</span>
                              </div>
                              <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30 shrink-0">
                                [{rel.relationCode}]
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground/60 italic p-3 bg-white/[0.02] rounded border border-white/5">
                          No explicit ontological relation syntax discovered in this segment. Concept proximity relations will be derived upon commit.
                        </p>
                      )}
                    </div>

                    {/* Detected Concepts & Entities */}
                    <div className="space-y-2">
                      <span className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                        <Cpu className="h-3 w-3 text-primary" /> Detected Conceptual Entities ({selectedAST.entities.length})
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedAST.entities.map((ent, idx) => {
                          let color = 'bg-white/5 text-muted-foreground border-white/10';
                          if (ent.category === 'pillar') color = 'bg-amber-500/10 text-amber-300 border-amber-500/30';
                          else if (ent.category === 'nihilist') color = 'bg-rose-500/10 text-rose-300 border-rose-500/30';
                          else if (ent.category === 'mystic') color = 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30';
                          else if (ent.category === 'concept') color = 'bg-primary/10 text-primary border-primary/30';

                          return (
                            <Badge key={idx} variant="outline" className={`text-xs py-1 px-2.5 font-normal ${color}`}>
                              {ent.name}
                              <span className="ml-1.5 text-[9px] opacity-60 font-mono">x{ent.frequency}</span>
                            </Badge>
                          );
                        })}
                      </div>
                    </div>

                    {/* Cleaned Text Preview */}
                    <div className="space-y-2">
                      <span className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                        <BookOpen className="h-3 w-3 text-emerald-400" /> Canonical Stripped Text Preview
                      </span>
                      <div className="p-3.5 rounded-lg bg-black/50 border border-white/5 text-xs text-muted-foreground leading-relaxed font-sans max-h-48 overflow-y-auto whitespace-pre-wrap select-text">
                        {selectedAST.cleanedText || selectedAST.rawContent}
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-muted-foreground/60">
                <Cpu className="h-10 w-10 mb-3 opacity-30 text-primary" />
                <h4 className="text-sm font-medium text-foreground">Canonical AST Inspector</h4>
                <p className="text-xs text-muted-foreground/70 max-w-sm mt-1">
                  Select a document from the pipeline queue on the left to inspect its extracted YAML frontmatter, wikilinks, and ontological triples.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-white/5 bg-[#0a0a10]/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="font-mono text-foreground font-semibold">
              {astQueue.filter((n) => n.status !== 'error').length} documents ready
            </span>
            <span>•</span>
            <span>
              {astQueue.reduce((acc, n) => acc + n.entities.length, 0)} total entities
            </span>
            <span>•</span>
            <span>
              {astQueue.reduce((acc, n) => acc + n.relations.length, 0)} relations
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadZip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/5 hover:bg-white/10 text-white/90 border border-white/10 text-xs font-medium transition-all cursor-pointer"
              title="Download standalone zip archive containing all 25 ingestion system files"
            >
              <Download className="h-3.5 w-3.5 text-emerald-400" />
              <span>Download System (.zip)</span>
            </button>
            <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)} className="text-xs text-muted-foreground hover:text-foreground">
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleCommitToPKM}
              disabled={astQueue.length === 0 || isProcessing}
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium text-xs px-5 shadow-[0_0_20px_rgba(138,43,226,0.3)] transition-all"
            >
              <Check className="h-3.5 w-3.5 mr-1.5" />
              Commit to PKM & Sync Knowledge Graph
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
