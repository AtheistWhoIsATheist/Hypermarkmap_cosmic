import { IngestedDocumentPayload } from '../lib/ingestion/types';

export interface SummaryResult {
  readonly content: string;
  readonly isCached: boolean;
  readonly timestamp: number;
  readonly wordCount: number;
  readonly reductionRatio: number;
}

export class DocumentSummarizerService {
  private static readonly CACHE_PREFIX = 'nks_summary_cache_';
  private static readonly MAX_CACHE_ENTRIES = 128;

  /**
   * Generates a deterministic SHA-256 equivalent content signature 
   * without pulling external heavy crypto bundles.
   */
  public static computeContentHash(doc: IngestedDocumentPayload): string {
    const raw = doc.rawText || '';
    const seed = `${doc.id}:${doc.filename}:${raw.length}:${raw.slice(0, 256)}:${raw.slice(-256)}`;
    let hash = 0x811c9dc5;
    for (let i = 0; i < seed.length; i++) {
      hash ^= seed.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193);
    }
    return (hash >>> 0).toString(16).padStart(8, '0');
  }

  /**
   * Retrieves summary from ascetic local storage if available.
   */
  public static getCachedSummary(hash: string): SummaryResult | null {
    try {
      const key = `${this.CACHE_PREFIX}${hash}`;
      const item = localStorage.getItem(key);
      if (!item) return null;

      // Parsing strict delimited representation: TIMESTAMP|WORDCOUNT|REDUCTION|CONTENT
      const delimiterIndex1 = item.indexOf('|');
      const delimiterIndex2 = item.indexOf('|', delimiterIndex1 + 1);
      const delimiterIndex3 = item.indexOf('|', delimiterIndex2 + 1);

      if (delimiterIndex1 === -1 || delimiterIndex2 === -1 || delimiterIndex3 === -1) {
        localStorage.removeItem(key);
        return null;
      }

      const timestamp = parseInt(item.substring(0, delimiterIndex1), 10);
      const wordCount = parseInt(item.substring(delimiterIndex1 + 1, delimiterIndex2), 10);
      const reductionRatio = parseFloat(item.substring(delimiterIndex2 + 1, delimiterIndex3));
      const content = item.substring(delimiterIndex3 + 1);

      return {
        content,
        isCached: true,
        timestamp,
        wordCount,
        reductionRatio
      };
    } catch {
      return null;
    }
  }

  /**
   * Persists summary using lean scalar concatenation, avoiding JSON structures.
   */
  public static setCachedSummary(hash: string, summaryText: string, originalWordCount: number): SummaryResult {
    const summaryWords = summaryText.split(/\s+/).filter(Boolean).length;
    const reductionRatio = originalWordCount > 0 ? Number((1 - (summaryWords / originalWordCount)).toFixed(2)) : 0;
    const timestamp = Date.now();

    const payload = `${timestamp}|${summaryWords}|${reductionRatio}|${summaryText}`;
    const key = `${this.CACHE_PREFIX}${hash}`;

    try {
      this.evictCacheIfFull();
      localStorage.setItem(key, payload);
    } catch {
      // Local storage full or blocked; fail gracefully
    }

    return {
      content: summaryText,
      isCached: false,
      timestamp,
      wordCount: summaryWords,
      reductionRatio
    };
  }

  /**
   * Executes AI cognitive distillation via server-side Gemini proxy (/api/ai/summarize).
   * Credentials remain strictly protected on the backend server.
   */
  public static async summarizeDocument(
    document: IngestedDocumentPayload
  ): Promise<SummaryResult> {
    const contentHash = this.computeContentHash(document);
    const cached = this.getCachedSummary(contentHash);
    if (cached) {
      return cached;
    }

    try {
      const response = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: document.filename,
          rawText: (document.rawText || '').slice(0, 16000),
          wordCount: document.wordCount,
        }),
      });

      if (!response.ok) {
        throw new Error(`Cognitive Gateway Error HTTP ${response.status}`);
      }

      const data = await response.json();
      const extractedText = data.summaryText;

      if (!extractedText || typeof extractedText !== 'string') {
        throw new Error('Malformed or empty distillation payload emitted by cognitive core.');
      }

      return this.setCachedSummary(contentHash, extractedText.trim(), document.wordCount);
    } catch {
      return this.generateAsceticHeuristicFallback(document, contentHash);
    }
  }

  private static generateAsceticHeuristicFallback(
    doc: IngestedDocumentPayload, 
    hash: string
  ): SummaryResult {
    const raw = doc.rawText || '';
    const firstSection = doc.sections[0]?.content.slice(0, 300) || raw.slice(0, 300);
    const middleSection = doc.sections[Math.floor(doc.sections.length / 2)]?.content.slice(0, 300) || '';
    
    const fallbackText = `### Core Ontological Thesis\nExtracted from document provenance *${doc.filename}*. Structural presence manifested through ${doc.wordCount} words.\n\n### Dialectical Tensions & Antinomies\n* Primary Node: Ingested format [${doc.format.toUpperCase()}] confronting cognitive reduction.\n* Secondary Aporia: Surface linguistic signifiers resisting foundational deconstruction.\n\n### Transcendent / Practical Synthesis\n*${firstSection.trim()}... ${middleSection ? `\n\nIntermediary Horizon: ${middleSection.trim()}...` : ''}*`;

    return this.setCachedSummary(hash, fallbackText, doc.wordCount);
  }

  private static evictCacheIfFull(): void {
    const keys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(this.CACHE_PREFIX)) {
        keys.push(k);
      }
    }

    if (keys.length >= this.MAX_CACHE_ENTRIES) {
      // Evict oldest quarter of the entries
      keys.slice(0, Math.floor(this.MAX_CACHE_ENTRIES / 4)).forEach(k => localStorage.removeItem(k));
    }
  }
}
