import { CanonicalASTNode, DocumentHeading, ExtractedEntity, ExtractedRelation } from './types';

// Standard InfraNodus ontological relation codes
export const KNOWN_RELATION_CODES = [
  'isA',
  'partOf',
  'hasAttribute',
  'relatedTo',
  'dependentOn',
  'causes',
  'locatedIn',
  'occursAt',
  'derivedFrom',
  'opposes',
] as const;

export function categorizeConcept(name: string): ExtractedEntity['category'] {
  const lower = name.toLowerCase();
  if (
    lower.includes('void') ||
    lower.includes('nothingness') ||
    lower.includes('nihiltheism') ||
    lower.includes('abyss') ||
    lower.includes('sacred dread') ||
    lower.includes('apophatic')
  ) {
    return 'pillar';
  }
  if (
    lower.includes('cioran') ||
    lower.includes('nietzsche') ||
    lower.includes('heidegger') ||
    lower.includes('schopenhauer') ||
    lower.includes('despair') ||
    lower.includes('meaninglessness') ||
    lower.includes('absurd')
  ) {
    return 'nihilist';
  }
  if (
    lower.includes('eckhart') ||
    lower.includes('mystic') ||
    lower.includes('unknowing') ||
    lower.includes('godhead') ||
    lower.includes('theology') ||
    lower.includes('transcendence') ||
    lower.includes('apophasis')
  ) {
    return 'mystic';
  }
  if (
    lower.includes('aporia') ||
    lower.includes('paradox') ||
    lower.includes('antinomy') ||
    lower.includes('contradiction')
  ) {
    return 'aporia';
  }
  return 'concept';
}

/**
 * Strips YAML frontmatter from markdown content and parses key-value pairs
 */
export function extractFrontmatter(content: string): { frontmatter: Record<string, any>; cleaned: string } {
  const frontmatterRegex = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/;
  const match = content.match(frontmatterRegex);

  if (!match) {
    return { frontmatter: {}, cleaned: content.trim() };
  }

  const rawYaml = match[1];
  const cleaned = content.slice(match[0].length).trim();
  const frontmatter: Record<string, any> = {};

  rawYaml.split(/\r?\n/).forEach((line) => {
    const colonIdx = line.indexOf(':');
    if (colonIdx > 0) {
      const key = line.slice(0, colonIdx).trim();
      let val: any = line.slice(colonIdx + 1).trim();

      // Simple array parsing e.g. [a, b, c] or clean string
      if (val.startsWith('[') && val.endsWith(']')) {
        val = val
          .slice(1, -1)
          .split(',')
          .map((s: string) => s.trim().replace(/^['"]|['"]$/g, ''))
          .filter(Boolean);
      } else {
        val = val.replace(/^['"]|['"]$/g, '');
      }

      if (key) {
        frontmatter[key] = val;
      }
    }
  });

  return { frontmatter, cleaned };
}

/**
 * Extract Markdown Headings (#, ##, ###)
 */
export function extractHeadings(markdown: string): DocumentHeading[] {
  const headingRegex = /^(#{1,6})\s+(.+)$/gm;
  const headings: DocumentHeading[] = [];
  let match: RegExpExecArray | null;

  while ((match = headingRegex.exec(markdown)) !== null) {
    headings.push({
      level: match[1].length,
      text: match[2].trim(),
    });
  }

  return headings;
}

/**
 * Extract wikilinks formatted as [[concept]] or [[concept|alias]]
 */
export function extractWikilinks(text: string): string[] {
  const linkRegex = /\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g;
  const links: Set<string> = new Set();
  let match: RegExpExecArray | null;

  while ((match = linkRegex.exec(text)) !== null) {
    const concept = match[1].trim();
    if (concept) {
      links.add(concept);
    }
  }

  return Array.from(links);
}

/**
 * Extract Ontological Relations matching [[entity1]] relation [[entity2]] [relationCode]
 */
export function extractOntologicalRelations(text: string): ExtractedRelation[] {
  const lines = text.split(/\r?\n/);
  const relations: ExtractedRelation[] = [];

  // Regex matches [[entity1]] ... [[entity2]] ... [relationCode]
  const pattern = /\[\[([^\]]+)\]\]\s+([\s\S]*?)\s+\[\[([^\]]+)\]\](?:\s*\[([^\]]+)\])?/;

  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed) return;

    const match = trimmed.match(pattern);
    if (match) {
      const entity1 = match[1].split('|')[0].trim();
      const relationDesc = match[2].trim();
      const entity2 = match[3].split('|')[0].trim();
      const relationCode = (match[4] || 'relatedTo').trim();

      relations.push({
        entity1,
        relationDescription: relationDesc || 'is connected to',
        entity2,
        relationCode,
        rawStatement: trimmed,
      });
    }
  });

  return relations;
}

/**
 * Calculate dynamic resonance score based on philosophical density
 */
export function calculateResonance(text: string, entitiesCount: number, relationsCount: number): number {
  let score = 0.5;
  const keywords = ['void', 'nothingness', 'apophatic', 'dread', 'transcendence', 'paradox', 'ontology', 'resonance'];
  const lower = text.toLowerCase();

  keywords.forEach((kw) => {
    if (lower.includes(kw)) score += 0.05;
  });

  score += Math.min(0.2, entitiesCount * 0.03);
  score += Math.min(0.15, relationsCount * 0.04);

  return Math.min(0.99, Math.round(score * 100) / 100);
}

/**
 * Strips markdown syntax to yield pure clean AST textual content
 */
export function stripMarkdownAST(markdown: string): string {
  return markdown
    .replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n?/g, '') // remove frontmatter
    .replace(/^#{1,6}\s+/gm, '') // headings
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, '') // images
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1') // links
    .replace(/\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g, '$1') // wikilinks
    .replace(/\[([a-zA-Z]+)\]/g, '') // relation tags
    .replace(/(\*\*|__)(.*?)\1/g, '$2') // bold
    .replace(/(\*|_)(.*?)\1/g, '$2') // italics
    .replace(/`{3}[\s\S]*?`{3}/g, '') // code blocks
    .replace(/`(.+?)`/g, '$1') // inline code
    .replace(/^>\s+/gm, '') // blockquotes
    .replace(/^\s*[-*+]\s+/gm, '') // unordered lists
    .replace(/^\s*\d+\.\s+/gm, '') // ordered lists
    .trim();
}

/**
 * Comprehensive parser for Markdown files returning CanonicalASTNode
 */
export function parseMarkdownFile(
  fileName: string,
  content: string,
  fileSize: number = 0,
  defaultProject: 'journal314' | 'ren' | 'general' = 'general'
): CanonicalASTNode {
  const { frontmatter, cleaned } = extractFrontmatter(content);
  const headings = extractHeadings(cleaned);
  const wikilinks = extractWikilinks(cleaned);
  const relations = extractOntologicalRelations(cleaned);
  const cleanedText = stripMarkdownAST(cleaned);

  // Determine Title
  let title = frontmatter.title;
  if (!title && headings.length > 0) {
    title = headings[0].text;
  }
  if (!title) {
    title = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  }

  // Determine Project ID
  let projectId: 'journal314' | 'ren' | 'general' = defaultProject;
  if (frontmatter.project === 'journal314' || frontmatter.project === 'ren' || frontmatter.project === 'general') {
    projectId = frontmatter.project;
  } else if (fileName.toLowerCase().includes('journal314')) {
    projectId = 'journal314';
  } else if (fileName.toLowerCase().includes('ren')) {
    projectId = 'ren';
  }

  // Aggregate entities
  const entityMap = new Map<string, { count: number; category: ExtractedEntity['category'] }>();

  // Add from wikilinks
  wikilinks.forEach((wl) => {
    const cat = categorizeConcept(wl);
    const existing = entityMap.get(wl);
    if (existing) {
      existing.count += 1;
    } else {
      entityMap.set(wl, { count: 1, category: cat });
    }
  });

  // Add from relations
  relations.forEach((rel) => {
    [rel.entity1, rel.entity2].forEach((ent) => {
      if (!entityMap.has(ent)) {
        entityMap.set(ent, { count: 1, category: categorizeConcept(ent) });
      } else {
        entityMap.get(ent)!.count += 1;
      }
    });
  });

  // Add from detected headings if meaningful
  headings.forEach((h) => {
    if (h.text.length < 30 && !entityMap.has(h.text)) {
      entityMap.set(h.text, { count: 1, category: categorizeConcept(h.text) });
    }
  });

  const entities: ExtractedEntity[] = Array.from(entityMap.entries()).map(([name, data]) => ({
    name,
    category: data.category,
    frequency: data.count,
    echo: `${data.category.toUpperCase()} // ${name}`,
  }));

  const detectedConcepts = entities.map((e) => e.name);
  const wordCount = cleanedText ? cleanedText.split(/\s+/).filter(Boolean).length : 0;
  const charCount = cleanedText.length;
  const resonanceScore = calculateResonance(cleanedText, entities.length, relations.length);

  return {
    id: `ast-${Math.random().toString(36).substring(2, 9)}`,
    fileName,
    fileType: 'md',
    fileSize,
    title,
    projectId,
    frontmatter,
    rawContent: content,
    cleanedText,
    headings,
    wikilinks,
    relations,
    entities,
    wordCount,
    charCount,
    detectedConcepts,
    resonanceScore,
    parsedAt: new Date().toISOString(),
    status: 'extracted',
    layoutFidelity: 'lossless',
  };
}
