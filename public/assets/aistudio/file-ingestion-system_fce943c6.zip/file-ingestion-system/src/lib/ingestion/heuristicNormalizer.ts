import { CanonicalASTNode, ExtractedEntity, ExtractedRelation } from './types';
import { categorizeConcept, calculateResonance, extractWikilinks, extractOntologicalRelations } from './astStripper';

/**
 * Heuristic normalizer for Plaintext (.txt) documents
 * Extracts sections, titles, capitalized philosophical concepts, and relations
 */
export function parsePlaintextFile(
  fileName: string,
  content: string,
  fileSize: number = 0,
  defaultProject: 'journal314' | 'ren' | 'general' = 'general'
): CanonicalASTNode {
  const lines = content.split(/\r?\n/).map((l) => l.trim());
  const nonEmptyLines = lines.filter(Boolean);

  // Heuristic 1: Title detection
  let title = '';
  if (nonEmptyLines.length > 0) {
    const firstLine = nonEmptyLines[0];
    if (firstLine.length < 90 && !firstLine.endsWith('.')) {
      title = firstLine.replace(/^[#\-*=\s]+/, '');
    }
  }
  if (!title) {
    title = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  }

  // Heuristic 2: Project detection from content or filename
  let projectId = defaultProject;
  const lowerContent = content.toLowerCase();
  if (lowerContent.includes('journal314') || fileName.toLowerCase().includes('journal314')) {
    projectId = 'journal314';
  } else if (lowerContent.includes('ren') || fileName.toLowerCase().includes('ren')) {
    projectId = 'ren';
  }

  // Heuristic 3: Check for explicit wikilinks or relations
  let wikilinks = extractWikilinks(content);
  let relations = extractOntologicalRelations(content);

  // Heuristic 4: Concept and Entity Extraction from Plaintext
  const entityMap = new Map<string, { count: number; category: ExtractedEntity['category'] }>();

  // Known philosophical vocabulary to scan for
  const philosophicalDictionary = [
    'The Void',
    'Nothingness',
    'Sacred Dread',
    'Apophatic Theology',
    'Emil Cioran',
    'Friedrich Nietzsche',
    'Martin Heidegger',
    'Meister Eckhart',
    'Arthur Schopenhauer',
    'Dasein',
    'Being-toward-death',
    'Will to Power',
    'Cloud of Unknowing',
    'Phenomenology',
    'Dialectical Tension',
    'Ontological Abyss',
    'Despair',
    'Apophatic Encounter',
    'Nihilism',
    'Nihiltheism',
  ];

  philosophicalDictionary.forEach((term) => {
    const regex = new RegExp(`\\b${term.replace(/[-\\/\\\\^$*+?.()|[\\]{}]/g, '\\$&')}\\b`, 'gi');
    const matches = content.match(regex);
    if (matches && matches.length > 0) {
      entityMap.set(term, {
        count: matches.length,
        category: categorizeConcept(term),
      });
      if (!wikilinks.includes(term)) {
        wikilinks.push(term);
      }
    }
  });

  // Heuristic 5: Capitalized multi-word concepts (e.g. "Sacred Horror", "Radical Negation")
  const capitalizedPattern = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b/g;
  let match: RegExpExecArray | null;
  while ((match = capitalizedPattern.exec(content)) !== null) {
    const candidate = match[1].trim();
    if (candidate.length > 4 && candidate.length < 35) {
      if (!entityMap.has(candidate)) {
        entityMap.set(candidate, {
          count: 1,
          category: categorizeConcept(candidate),
        });
      } else {
        entityMap.get(candidate)!.count += 1;
      }
    }
  }

  // If no relations exist yet, generate resonant proximity relations between top discovered entities
  if (relations.length === 0 && entityMap.size >= 2) {
    const topEntities = Array.from(entityMap.keys()).slice(0, 4);
    for (let i = 0; i < topEntities.length - 1; i++) {
      const e1 = topEntities[i];
      const e2 = topEntities[i + 1];
      const relCode = i % 2 === 0 ? 'relatedTo' : 'causes';
      relations.push({
        entity1: e1,
        relationDescription: 'dialectically engages with',
        entity2: e2,
        relationCode: relCode,
        rawStatement: `[[${e1}]] dialectically engages with [[${e2}]] [${relCode}]`,
      });
    }
  }

  const entities: ExtractedEntity[] = Array.from(entityMap.entries()).map(([name, data]) => ({
    name,
    category: data.category,
    frequency: data.count,
    echo: `${data.category.toUpperCase()} // ${name}`,
  }));

  const detectedConcepts = entities.map((e) => e.name);
  const wordCount = content.split(/\s+/).filter(Boolean).length;
  const charCount = content.length;
  const resonanceScore = calculateResonance(content, entities.length, relations.length);

  return {
    id: `ast-${Math.random().toString(36).substring(2, 9)}`,
    fileName,
    fileType: 'txt',
    fileSize,
    title,
    projectId,
    frontmatter: {},
    rawContent: content,
    cleanedText: content.trim(),
    headings: [{ level: 1, text: title }],
    wikilinks,
    relations,
    entities,
    wordCount,
    charCount,
    detectedConcepts,
    resonanceScore,
    parsedAt: new Date().toISOString(),
    status: 'extracted',
    layoutFidelity: 'lossless',
  };
}
