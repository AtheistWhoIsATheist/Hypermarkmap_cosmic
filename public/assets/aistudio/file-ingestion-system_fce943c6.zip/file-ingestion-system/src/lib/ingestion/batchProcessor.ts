import { CanonicalASTNode, IngestionBatchSummary } from './types';
import { parseMarkdownFile } from './astStripper';
import { parsePlaintextFile } from './heuristicNormalizer';
import { parsePDFFile } from './pdfStreamReader';

export interface ProgressCallback {
  (progressPercent: number, currentItem: number, total: number, message: string, latestNode?: CanonicalASTNode): void;
}

/**
 * Process a single uploaded file
 */
export async function processFileToAST(
  file: File,
  defaultProject: 'journal314' | 'ren' | 'general' = 'general'
): Promise<CanonicalASTNode> {
  const extension = file.name.split('.').pop()?.toLowerCase();

  if (extension === 'md' || extension === 'markdown') {
    const text = await file.text();
    return parseMarkdownFile(file.name, text, file.size, defaultProject);
  } else if (extension === 'txt') {
    const text = await file.text();
    return parsePlaintextFile(file.name, text, file.size, defaultProject);
  } else if (extension === 'pdf') {
    const arrayBuffer = await file.arrayBuffer();
    return await parsePDFFile(file.name, arrayBuffer, file.size, defaultProject);
  } else {
    // Fallback as plaintext
    const text = await file.text();
    return parsePlaintextFile(file.name, text, file.size, defaultProject);
  }
}

/**
 * Process a batch of files with live progress
 */
export async function processBatchFiles(
  files: File[],
  defaultProject: 'journal314' | 'ren' | 'general' = 'general',
  onProgress?: ProgressCallback
): Promise<{ nodes: CanonicalASTNode[]; summary: IngestionBatchSummary }> {
  const startedAt = new Date().toISOString();
  const total = files.length;
  const nodes: CanonicalASTNode[] = [];

  for (let i = 0; i < total; i++) {
    const file = files[i];
    const pct = Math.round(((i) / total) * 100);
    onProgress?.(pct, i + 1, total, `Parsing ${file.name}...`);

    try {
      const astNode = await processFileToAST(file, defaultProject);
      nodes.push(astNode);
      onProgress?.(
        Math.round(((i + 1) / total) * 100),
        i + 1,
        total,
        `Extracted ${astNode.detectedConcepts.length} concepts from ${file.name}`,
        astNode
      );
    } catch (err: any) {
      console.error(`Failed to ingest file ${file.name}:`, err);
      // Create error AST node so user is informed
      nodes.push({
        id: `err-${Math.random().toString(36).substring(2, 9)}`,
        fileName: file.name,
        fileType: (file.name.split('.').pop()?.toLowerCase() as any) || 'txt',
        fileSize: file.size,
        title: file.name,
        projectId: defaultProject,
        frontmatter: {},
        rawContent: '',
        cleanedText: '',
        headings: [],
        wikilinks: [],
        relations: [],
        entities: [],
        wordCount: 0,
        charCount: 0,
        detectedConcepts: [],
        resonanceScore: 0,
        parsedAt: new Date().toISOString(),
        status: 'error',
        errorMessage: err.message || 'Unknown processing error',
      });
    }
  }

  const processedNodes = nodes.filter((n) => n.status !== 'error');
  const summary: IngestionBatchSummary = {
    totalFiles: total,
    processedFiles: processedNodes.length,
    totalEntitiesExtracted: processedNodes.reduce((acc, n) => acc + n.entities.length, 0),
    totalRelationsExtracted: processedNodes.reduce((acc, n) => acc + n.relations.length, 0),
    totalWords: processedNodes.reduce((acc, n) => acc + n.wordCount, 0),
    startedAt,
    completedAt: new Date().toISOString(),
  };

  return { nodes, summary };
}

/**
 * Built-in Sample Corpus for immediate one-click testing
 */
export const SAMPLE_NIHILTHEISM_CORPUS = [
  {
    fileName: 'apophatic_theology_and_the_void.md',
    project: 'journal314' as const,
    content: `---
title: Apophatic Theology and the Collapse of Meaning
author: NKS Research Collective
project: journal314
tags: [theology, void, apophasis, cioran]
status: peer-reviewed
date: 2026-04-12
---

# Apophatic Theology and the Collapse of Meaning

The structural resonance between classical apophatic mysticism and contemporary nihilism rests on the refusal to formulate positive predicates for the ultimate horizon. In Pseudo-Dionysius and Meister Eckhart, the [[Apophatic Void]] is not absence in the vulgar sense, but an overwhelming excess of reality that blindingly exceeds conceptual containment.

## Foundational Dialectics

When [[Emil Cioran]] encounters the collapse of rational teleology, his reaction is structurally symmetrical to the contemplative entering the [[Cloud of Unknowing]].

[[Apophatic Void]] is structurally identical to [[Nihiltheism]] [isA]
[[Sacred Dread]] emerges from the confrontation with [[The Void]] [causes]
[[Meister Eckhart]] proposed radical detachment from [[Godhead]] [derivedFrom]
[[The Void]] dismantles any positive ontological [[Teleology]] [opposes]
[[Apophatic Theology]] requires continuous discipline in [[Negative Theology]] [dependentOn]
[[Sacred Dread]] constitutes the phenomenological heart of [[Numinous Core]] [partOf]
[[Emil Cioran]] critiques the illusions of [[Rationalism]] [opposes]
[[Despair]] functions as the threshold to [[Transcendent Resonance]] [causes]

## Synthesis and Horizon

The apophatic thinker does not run from meaninglessness; they inhabit it until meaninglessness itself burns away the ego's idols.
`,
  },
  {
    fileName: 'cioran_fragments_on_despair.txt',
    project: 'ren' as const,
    content: `Phenomenology of Despair and the Anti-System
Emil Cioran Fragments — NKS Ingestion Stream

The moment man ceases to believe in the absolute, he discovers that the absolute was merely the shadow cast by his longing.
What we call Sacred Dread is the shivering of the mind before its own ungroundedness.

In Martin Heidegger, we observe how Being-toward-death forces Dasein out of the idle chatter of everydayness into the stark confrontation with Nothingness. 
Yet Arthur Schopenhauer had already perceived that the Will to Power or the blind Will is an engine of perpetual craving without an inherent purpose.

Key Axioms:
[[Emil Cioran]] exposes the existential paralysis of [[Despair]] [hasAttribute]
[[Being-toward-death]] awakens the human subject to [[Nothingness]] [causes]
[[Martin Heidegger]] situates existential dread within [[Dasein]] [locatedIn]
[[Arthur Schopenhauer]] identifies universal suffering as [[Blind Will]] [isA]
[[Nihiltheism]] transforms passive nihilism into [[Active Affirmation]] [causes]
`,
  },
  {
    fileName: 'meister_eckhart_and_the_groundless_godhead.md',
    project: 'journal314' as const,
    content: `---
title: Meister Eckhart and the Groundless Godhead
project: journal314
tags: [mysticism, eckhart, abyss, ontology]
---

# Meister Eckhart and the Groundless Godhead

Meister Eckhart's distinction between God (Gott) and the Godhead (Gottheit) anticipates the deepest insights of modern speculative philosophy. The Godhead is the pure ungrounded Abyss, beyond Being and Non-Being.

## Relational Matrix

[[Meister Eckhart]] transcends conventional scholasticism toward [[The Godhead]] [causes]
[[The Godhead]] operates as a pure unconditioned [[Ontological Abyss]] [isA]
[[Apophatic Void]] directly echoes the silent desert of [[The Godhead]] [relatedTo]
[[Friedrich Nietzsche]] proclaimed the dissolution of transcendent values through [[God is Dead]] [causes]
[[God is Dead]] confronts Western civilization with the [[Ontological Abyss]] [causes]
[[Sacred Dread]] serves as an experiential conduit to [[Apophatic Void]] [relatedTo]
`,
  },
];

/**
 * Load sample corpus as AST nodes
 */
export function loadSampleCorpusToAST(): CanonicalASTNode[] {
  return SAMPLE_NIHILTHEISM_CORPUS.map((sample) => {
    if (sample.fileName.endsWith('.md')) {
      return parseMarkdownFile(sample.fileName, sample.content, sample.content.length, sample.project);
    } else {
      return parsePlaintextFile(sample.fileName, sample.content, sample.content.length, sample.project);
    }
  });
}
