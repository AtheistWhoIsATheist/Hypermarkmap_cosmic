import * as pdfjsLib from 'pdfjs-dist';
import { CanonicalASTNode, ExtractedEntity, ExtractedRelation } from './types';
import { categorizeConcept, calculateResonance, extractWikilinks, extractOntologicalRelations } from './astStripper';

// Configure pdfjs worker if in browser
if (typeof window !== 'undefined') {
  try {
    // Use worker from unpkg or pdfjs-dist build if available
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
  } catch (e) {
    console.warn('Could not set pdf.js worker src, will attempt standard stream read', e);
  }
}

/**
 * Extract raw text streams and spatial reassembly from PDF ArrayBuffer
 */
export async function extractTextFromPDF(arrayBuffer: ArrayBuffer): Promise<{ text: string; pagesCount: number }> {
  try {
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
    const pdfDoc = await loadingTask.promise;
    const pagesCount = pdfDoc.numPages;
    const pageTexts: string[] = [];

    for (let pageNum = 1; pageNum <= pagesCount; pageNum++) {
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      // Spatial reassembly: sort by vertical position Y (descending) and horizontal X (ascending)
      const items = textContent.items as Array<{ str: string; transform: number[] }>;
      let lastY: number | null = null;
      let pageStr = '';

      items.forEach((item) => {
        if (!item.str) return;
        const currentY = item.transform ? item.transform[5] : null;

        if (lastY !== null && currentY !== null && Math.abs(currentY - lastY) > 8) {
          pageStr += '\n';
        } else if (pageStr.length > 0 && !pageStr.endsWith(' ') && !pageStr.endsWith('\n')) {
          pageStr += ' ';
        }

        pageStr += item.str;
        if (currentY !== null) lastY = currentY;
      });

      pageTexts.push(`--- Page ${pageNum} ---\n${pageStr.trim()}`);
    }

    return {
      text: pageTexts.join('\n\n'),
      pagesCount,
    };
  } catch (error) {
    console.error('Failed to parse PDF stream with pdf.js:', error);
    throw new Error(`PDF Parsing Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Spatial reassembler and canonical AST builder for PDF files
 */
export async function parsePDFFile(
  fileName: string,
  arrayBuffer: ArrayBuffer,
  fileSize: number = 0,
  defaultProject: 'journal314' | 'ren' | 'general' = 'general'
): Promise<CanonicalASTNode> {
  const { text: extractedText, pagesCount } = await extractTextFromPDF(arrayBuffer);

  // Determine Title from first substantial line
  const lines = extractedText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  let title = '';
  for (const line of lines) {
    if (line.startsWith('--- Page')) continue;
    if (line.length > 3 && line.length < 90) {
      title = line;
      break;
    }
  }
  if (!title) {
    title = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  }

  // Determine Project
  let projectId = defaultProject;
  const lower = (fileName + ' ' + extractedText).toLowerCase();
  if (lower.includes('journal314')) projectId = 'journal314';
  else if (lower.includes('ren')) projectId = 'ren';

  // Extract explicit relations and wikilinks if present in text
  const wikilinks = extractWikilinks(extractedText);
  const relations = extractOntologicalRelations(extractedText);

  // Philosophical dictionary scan
  const entityMap = new Map<string, { count: number; category: ExtractedEntity['category'] }>();
  const dictionary = [
    'The Void',
    'Nothingness',
    'Sacred Dread',
    'Apophatic Theology',
    'Emil Cioran',
    'Friedrich Nietzsche',
    'Martin Heidegger',
    'Meister Eckhart',
    'Arthur Schopenhauer',
    'Dasein',
    'Being-toward-death',
    'Cloud of Unknowing',
    'Phenomenology',
    'Ontological Paradox',
    'Despair',
    'Negative Theology',
    'Transcendence',
    'Apophatic Encounter',
    'Nihiltheism',
  ];

  dictionary.forEach((term) => {
    const regex = new RegExp(`\\b${term.replace(/[-\\/\\\\^$*+?.()|[\\]{}]/g, '\\$&')}\\b`, 'gi');
    const matches = extractedText.match(regex);
    if (matches && matches.length > 0) {
      entityMap.set(term, {
        count: matches.length,
        category: categorizeConcept(term),
      });
      if (!wikilinks.includes(term)) {
        wikilinks.push(term);
      }
    }
  });

  // Extract headings from page markers and capitalized titles
  const headings = [
    { level: 1, text: title },
    ...Array.from({ length: pagesCount }, (_, i) => ({
      level: 2,
      text: `Section / Page ${i + 1}`,
    })),
  ];

  // Synthesize relations if none were explicitly parsed
  if (relations.length === 0 && entityMap.size >= 2) {
    const list = Array.from(entityMap.keys()).slice(0, 5);
    for (let i = 0; i < list.length - 1; i++) {
      const e1 = list[i];
      const e2 = list[i + 1];
      const code = i === 0 ? 'causes' : i === 1 ? 'partOf' : 'relatedTo';
      relations.push({
        entity1: e1,
        relationDescription: 'theoretically unfolds into',
        entity2: e2,
        relationCode: code,
        rawStatement: `[[${e1}]] theoretically unfolds into [[${e2}]] [${code}]`,
      });
    }
  }

  const entities: ExtractedEntity[] = Array.from(entityMap.entries()).map(([name, data]) => ({
    name,
    category: data.category,
    frequency: data.count,
    echo: `${data.category.toUpperCase()} // ${name}`,
  }));

  const detectedConcepts = entities.map((e) => e.name);
  const wordCount = extractedText.split(/\s+/).filter(Boolean).length;
  const charCount = extractedText.length;
  const resonanceScore = calculateResonance(extractedText, entities.length, relations.length);

  return {
    id: `ast-${Math.random().toString(36).substring(2, 9)}`,
    fileName,
    fileType: 'pdf',
    fileSize,
    title,
    projectId,
    frontmatter: { pagesCount, sourceFormat: 'PDF Document' },
    rawContent: extractedText,
    cleanedText: extractedText,
    headings,
    wikilinks,
    relations,
    entities,
    wordCount,
    charCount,
    detectedConcepts,
    resonanceScore,
    parsedAt: new Date().toISOString(),
    status: 'extracted',
    layoutFidelity: 'heuristic-approximate',
    layoutWarning: 'PDF text extraction is a heuristic spatial reassembly and cannot guarantee lossless layout. Converting complex PDFs to Markdown (via marker, pdftotext, or MarkItDown) before ingestion is recommended for lossless structural fidelity.',
  };
}
