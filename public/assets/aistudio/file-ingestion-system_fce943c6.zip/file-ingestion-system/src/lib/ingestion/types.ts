export type SupportedInputFormat = 'md' | 'txt' | 'pdf';
export type SupportedExportFormat = 'md' | 'txt' | 'pdf';

export type NodeType = 'pillar' | 'nihilist' | 'mystic' | 'concept' | 'aporia';

export type LayoutFidelity = 'lossless' | 'heuristic-approximate';

export interface DocumentSection {
  readonly title: string;
  readonly content: string;
  readonly depth: number;
}

export interface IngestedDocumentPayload {
  readonly id: string;
  readonly filename: string;
  readonly format: SupportedInputFormat;
  readonly rawText: string;
  readonly sections: ReadonlyArray<DocumentSection>;
  readonly wordCount: number;
  readonly ingestedAt: number;
}

export interface KnowledgeNode {
  readonly id: string;
  readonly label: string;
  readonly type: NodeType;
  readonly definition: string;
  readonly weight: number;
  readonly sourceDocId: string;
  readonly sourceFilename: string;
  x?: number;
  y?: number;
  vx?: number;
  vy?: number;
  fx?: number | null;
  fy?: number | null;
}

export interface KnowledgeEdge {
  readonly id: string;
  readonly source: string;
  readonly target: string;
  readonly relation: string;
  readonly dialecticalTension: number;
  readonly citation: string;
}

export interface DialecticalInsight {
  readonly id: string;
  readonly title: string;
  readonly thesis: string;
  readonly antithesis: string;
  readonly synthesis: string;
  readonly tensionScore: number;
  readonly sourceNodeIds: ReadonlyArray<string>;
  readonly timestamp: number;
}

export interface IngestionBatchProgress {
  readonly total: number;
  readonly current: number;
  readonly currentFilename: string;
  readonly errors: ReadonlyArray<{ filename: string; reason: string }>;
}

export interface IngestionProgress {
  readonly totalFiles: number;
  readonly processedFiles: number;
  readonly currentFileName: string;
  readonly percent: number;
  readonly status: 'idle' | 'processing' | 'completed' | 'failed';
}

export interface DocumentHeading {
  readonly level: number;
  readonly text: string;
}

export type CanonicalRelationSchema = 
  | 'isA'
  | 'causes'
  | 'partOf'
  | 'contrastsWith'
  | 'supports'
  | 'negates'
  | 'references'
  | 'resonatesWith'
  | 'hasAttribute'
  | 'relatedTo'
  | 'dependentOn'
  | 'locatedIn'
  | 'occursAt'
  | 'derivedFrom'
  | 'opposes';

export interface ExtractedRelation {
  readonly entity1: string;
  readonly relationDescription: string;
  readonly entity2: string;
  readonly relationCode: CanonicalRelationSchema | string;
  readonly rawStatement: string;
}

export interface ExtractedEntity {
  readonly name: string;
  readonly category: NodeType;
  readonly frequency: number;
  readonly echo?: string;
  readonly definition?: string;
}

export interface DocumentMetadata {
  readonly title?: string;
  readonly author?: string;
  readonly date?: string;
  readonly tags?: ReadonlyArray<string>;
  readonly projectId?: 'journal314' | 'ren' | 'general';
  readonly sourceFormat?: string;
  readonly pagesCount?: number;
  readonly [key: string]: any;
}

export interface DocumentChunk {
  readonly id: string;
  readonly documentId: string;
  readonly chunkIndex: number;
  readonly text: string;
  readonly wordCount: number;
  readonly headings: ReadonlyArray<string>;
  readonly entities: ReadonlyArray<string>;
}

export interface IngestionFile {
  readonly name: string;
  readonly size: number;
  readonly type: string;
  readonly extension: SupportedInputFormat;
  readonly content: string | ArrayBuffer;
}

export interface ParsedDocument {
  readonly id: string;
  readonly fileName: string;
  readonly fileType: SupportedInputFormat;
  readonly fileSize: number;
  readonly metadata: DocumentMetadata;
  readonly rawText: string;
  readonly cleanedText: string;
  readonly headings: ReadonlyArray<DocumentHeading>;
  readonly wikilinks: ReadonlyArray<string>;
  readonly relations: ReadonlyArray<ExtractedRelation>;
  readonly entities: ReadonlyArray<ExtractedEntity>;
  readonly chunks: ReadonlyArray<DocumentChunk>;
  readonly layoutFidelity: LayoutFidelity;
  readonly layoutWarning?: string;
}

export interface GraphNodeCandidate {
  readonly id: string;
  readonly label: string;
  readonly type: NodeType;
  readonly definition: string;
  readonly weight: number;
  readonly sourceDocId: string;
  readonly sourceFilename: string;
}

export interface GraphEdgeCandidate {
  readonly id: string;
  readonly source: string;
  readonly target: string;
  readonly relation: CanonicalRelationSchema | string;
  readonly dialecticalTension: number;
  readonly citation: string;
}

export interface IngestionError {
  readonly fileName: string;
  readonly errorCode: string;
  readonly message: string;
  readonly details?: string;
}

export interface IngestionResult {
  readonly success: boolean;
  readonly astNode?: CanonicalASTNode;
  readonly error?: IngestionError;
}

export interface CanonicalASTDocument {
  readonly id: string;
  readonly fileName: string;
  readonly fileType: SupportedInputFormat;
  readonly fileSize: number;
  readonly title: string;
  readonly projectId: 'journal314' | 'ren' | 'general';
  readonly frontmatter: DocumentMetadata;
  readonly rawContent: string;
  readonly cleanedText: string;
  readonly headings: ReadonlyArray<DocumentHeading>;
  readonly wikilinks: ReadonlyArray<string>;
  readonly relations: ReadonlyArray<ExtractedRelation>;
  readonly entities: ReadonlyArray<ExtractedEntity>;
  readonly wordCount: number;
  readonly charCount: number;
  readonly detectedConcepts: ReadonlyArray<string>;
  readonly resonanceScore: number;
  readonly summary?: string;
  readonly parsedAt: string;
  readonly status: 'queued' | 'parsing' | 'extracted' | 'error' | 'committed';
  readonly errorMessage?: string;
  readonly layoutFidelity?: LayoutFidelity;
  readonly layoutWarning?: string;
}

export interface CanonicalTokenDictionary {
  readonly pillars: ReadonlyArray<string>;
  readonly nihilists: ReadonlyArray<string>;
  readonly mystics: ReadonlyArray<string>;
  readonly concepts: ReadonlyArray<string>;
  readonly aporias: ReadonlyArray<string>;
}

export interface CanonicalASTNode extends CanonicalASTDocument {}

export interface IngestionBatchSummary {
  readonly totalFiles: number;
  readonly processedFiles: number;
  readonly totalEntitiesExtracted: number;
  readonly totalRelationsExtracted: number;
  readonly totalWords: number;
  readonly startedAt: string;
  readonly completedAt?: string;
}

export interface BatchIngestionSummary extends IngestionBatchSummary {
  readonly successfulFiles: number;
  readonly failedFiles: number;
  readonly errors: ReadonlyArray<IngestionError>;
}
