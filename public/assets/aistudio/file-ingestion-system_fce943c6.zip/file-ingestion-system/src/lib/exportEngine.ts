import { KnowledgeNode, KnowledgeEdge, SupportedExportFormat } from './ingestion/types';
import { jsPDF } from 'jspdf';

export interface ExportGraphState {
  readonly nodes: ReadonlyMap<string, KnowledgeNode>;
  readonly edges: ReadonlyMap<string, KnowledgeEdge>;
}

export function exportToMarkdown(state: ExportGraphState): string {
  return ExportEngine.generateMarkdown(state);
}

export function exportToPlainText(state: ExportGraphState): string {
  return ExportEngine.generatePlainText(state);
}

export function exportToPdf(state: ExportGraphState, filename: string): void {
  ExportEngine.export(state, 'pdf', filename);
}

export class ExportEngine {
  public static export(state: ExportGraphState, format: SupportedExportFormat, baseName = 'NKS_Ontological_Audit'): void {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${baseName}_${timestamp}`;

    switch (format) {
      case 'md':
        this.downloadFile(`${filename}.md`, this.generateMarkdown(state), 'text/markdown');
        break;
      case 'txt':
        this.downloadFile(`${filename}.txt`, this.generatePlainText(state), 'text/plain');
        break;
      case 'pdf':
        this.generatePdf(state, `${filename}.pdf`);
        break;
      default:
        throw new Error(`Unsupported export format. Supported formats are strictly .md, .txt, and .pdf.`);
    }
  }

  public static generateMarkdown(state: ExportGraphState): string {
    const lines: string[] = [];
    lines.push('---');
    lines.push(`title: Ontological Knowledge Network`);
    lines.push(`generated: ${new Date().toISOString()}`);
    lines.push(`total_nodes: ${state.nodes.size}`);
    lines.push(`total_edges: ${state.edges.size}`);
    lines.push('---\n');

    lines.push('# NIHILTHEISM KNOWLEDGE NETWORK AUDIT\n');
    lines.push('> Canonical export derived from the Nihiltheism Knowledge System (NKS v3.0).\n');

    lines.push('## 1. Morphological Entities & Conceptual Nodes\n');
    lines.push('| Identifier | Entity Label | Morphological Type | Weight | Originating Source | Definition |');
    lines.push('| :--- | :--- | :--- | :---: | :--- | :--- |');

    for (const node of state.nodes.values()) {
      const cleanDef = (node.definition || '').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
      lines.push(`| \`${node.id}\` | **[[${node.label}]]** | \`${node.type.toUpperCase()}\` | ${node.weight}/10 | _${node.sourceFilename || 'NKS Core'}_ | ${cleanDef} |`);
    }

    lines.push('\n## 2. Dialectical Sutures & Relational Tensions\n');
    lines.push('| Source Entity | Dialectical Relation | Target Entity | Tension Score | Textual / Phenomenological Citation |');
    lines.push('| :--- | :---: | :--- | :---: | :--- |');

    for (const edge of state.edges.values()) {
      const srcNode = state.nodes.get(edge.source);
      const tgtNode = state.nodes.get(edge.target);
      const srcLabel = srcNode ? `[[${srcNode.label}]]` : `\`${edge.source}\``;
      const tgtLabel = tgtNode ? `[[${tgtNode.label}]]` : `\`${edge.target}\``;
      const cleanCitation = (edge.citation || '').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
      lines.push(`| ${srcLabel} | \`[${edge.relation}]\` | ${tgtLabel} | **${(edge.dialecticalTension * 100).toFixed(0)}%** | ${cleanCitation} |`);
    }

    lines.push('\n---\n*End of Ontological Export.*');
    return lines.join('\n');
  }

  public static generatePlainText(state: ExportGraphState): string {
    const lines: string[] = [];
    const sep = '='.repeat(84);
    const subSep = '-'.repeat(84);

    lines.push(sep);
    lines.push('               NIHILTHEISM KNOWLEDGE SYSTEM (NKS) — TOPOLOGICAL AUDIT          ');
    lines.push(sep);
    lines.push(`Generated: ${new Date().toISOString()}`);
    lines.push(`Metrics:   Total Entities: ${state.nodes.size} | Total Sutures: ${state.edges.size}`);
    lines.push(sep);
    lines.push('');

    lines.push('[I. ENTITY MANIFEST]');
    lines.push(subSep);
    for (const node of state.nodes.values()) {
      lines.push(`• [${node.type.toUpperCase()}] ${node.label} (Dialectical Weight: ${node.weight}/10)`);
      lines.push(`  ID:         ${node.id}`);
      lines.push(`  Provenance: ${node.sourceFilename || 'NKS Core'}`);
      lines.push(`  Definition: ${node.definition}`);
      lines.push('');
    }

    lines.push('');
    lines.push('[II. RELATIONAL ADJACENCY MATRIX & DIALECTICAL SUTURES]');
    lines.push(subSep);
    for (const edge of state.edges.values()) {
      const src = state.nodes.get(edge.source)?.label || edge.source;
      const tgt = state.nodes.get(edge.target)?.label || edge.target;
      lines.push(`• ${src}`);
      lines.push(`    ──[ ${edge.relation.toUpperCase()} (Tension: ${(edge.dialecticalTension * 100).toFixed(0)}%) ]──►`);
      lines.push(`  ${tgt}`);
      lines.push(`  Context: "${edge.citation}"`);
      lines.push('');
    }

    lines.push(sep);
    lines.push('                    END OF TRANSMISSION — ZERO-LOSS VERIFIED                  ');
    lines.push(sep);

    return lines.join('\n');
  }

  public static generatePdf(state: ExportGraphState, outputFilename: string): void {
    const doc = new jsPDF({ unit: 'pt', format: 'letter' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 48;
    const contentWidth = pageWidth - margin * 2;
    let cursorY = margin;

    const enforcePageBreak = (requiredHeight: number) => {
      if (cursorY + requiredHeight > pageHeight - margin) {
        doc.addPage();
        cursorY = margin;
        renderHeader();
      }
    };

    const renderHeader = () => {
      doc.setFont('courier', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(140, 140, 140);
      doc.text(`NKS v3.0 ONTOLOGICAL GRAPH REPORT — RECORD ${Date.now()}`, margin, cursorY);
      cursorY += 14;
      doc.setDrawColor(210, 210, 210);
      doc.line(margin, cursorY, pageWidth - margin, cursorY);
      cursorY += 18;
    };

    renderHeader();

    // Document Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.setTextColor(15, 23, 42);
    doc.text('Ontological Knowledge Graph Audit', margin, cursorY);
    cursorY += 22;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text(`Generated: ${new Date().toUTCString()} | Active Entities: ${state.nodes.size} | Relational Sutures: ${state.edges.size}`, margin, cursorY);
    cursorY += 24;

    // Section 1: Entities
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(30, 41, 59);
    doc.text('1. Comprehended Morphological Entities', margin, cursorY);
    cursorY += 16;

    for (const node of state.nodes.values()) {
      enforcePageBreak(54);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(14, 116, 144);
      doc.text(`• [${node.type.toUpperCase()}] ${node.label}`, margin + 8, cursorY);
      
      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(`Weight: ${node.weight}/10 | Origin: ${node.sourceFilename || 'NKS'}`, margin + 240, cursorY);
      cursorY += 13;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(51, 65, 85);
      const wrappedDef = doc.splitTextToSize(node.definition || '', contentWidth - 24);
      doc.text(wrappedDef, margin + 16, cursorY);
      cursorY += wrappedDef.length * 11 + 8;
    }

    cursorY += 10;
    enforcePageBreak(50);

    // Section 2: Relational Sutures
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(30, 41, 59);
    doc.text('2. Relational Sutures & Dialectical Antinomies', margin, cursorY);
    cursorY += 16;

    for (const edge of state.edges.values()) {
      enforcePageBreak(44);

      const src = state.nodes.get(edge.source)?.label || edge.source;
      const tgt = state.nodes.get(edge.target)?.label || edge.target;

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text(`${src}  ──[ ${edge.relation.toUpperCase()} ]──►  ${tgt}`, margin + 8, cursorY);
      cursorY += 12;

      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      const wrappedCitation = doc.splitTextToSize(`Tension: ${(edge.dialecticalTension * 100).toFixed(0)}% | Citation: "${edge.citation || ''}"`, contentWidth - 24);
      doc.text(wrappedCitation, margin + 16, cursorY);
      cursorY += wrappedCitation.length * 10 + 6;
    }

    // Number every page cleanly
    const totalPages = doc.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(160, 160, 160);
      doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin - 50, pageHeight - 24);
    }

    doc.save(outputFilename);
  }

  public static downloadFile(filename: string, textContent: string, mimeType: string): void {
    const blob = new Blob([textContent], { type: `${mimeType};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
