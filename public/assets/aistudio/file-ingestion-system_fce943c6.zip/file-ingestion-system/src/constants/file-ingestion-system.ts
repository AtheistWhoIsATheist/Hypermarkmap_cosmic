/**
 * Central File Ingestion System Specifications & Constraints
 * Defines supported formats, MIME constraints, limits, fidelity labels, and status codes.
 */

import { SupportedInputFormat, SupportedExportFormat, CanonicalRelationSchema, LayoutFidelity } from '../lib/ingestion/types';

export const SUPPORTED_INPUT_FORMATS: ReadonlyArray<SupportedInputFormat> = ['md', 'txt', 'pdf'];
export const SUPPORTED_EXPORT_FORMATS: ReadonlyArray<SupportedExportFormat> = ['md', 'txt', 'pdf'];

export const FILE_EXTENSIONS_MAP: Record<string, SupportedInputFormat> = {
  md: 'md',
  markdown: 'md',
  txt: 'txt',
  text: 'txt',
  pdf: 'pdf',
};

export const MIME_TYPE_MAP: Record<string, SupportedInputFormat> = {
  'text/markdown': 'md',
  'text/x-markdown': 'md',
  'text/plain': 'txt',
  'application/pdf': 'pdf',
};

export const INGESTION_LIMITS = {
  MAX_FILE_SIZE_BYTES: 25 * 1024 * 1024, // 25 MB
  MAX_BATCH_FILES: 100,
  CHUNK_TARGET_WORD_COUNT: 500,
  CHUNK_OVERLAP_WORDS: 50,
  MAX_CONCURRENT_PARSES: 4,
} as const;

export const LAYOUT_FIDELITY_LABELS: Record<LayoutFidelity, { label: string; description: string }> = {
  'lossless': {
    label: 'Lossless AST',
    description: 'Direct syntactic tree extraction preserving structural hierarchy, frontmatter, and code blocks.',
  },
  'heuristic-approximate': {
    label: 'Heuristic Approximate',
    description: 'Spatial stream reassembly. Layout, columns, tables, or formatting cannot be guaranteed lossless.',
  },
};

export const CANONICAL_RELATION_CODES: ReadonlyArray<CanonicalRelationSchema> = [
  'isA',
  'causes',
  'partOf',
  'contrastsWith',
  'supports',
  'negates',
  'references',
  'resonatesWith',
  'hasAttribute',
  'relatedTo',
  'dependentOn',
  'locatedIn',
  'occursAt',
  'derivedFrom',
  'opposes',
];

export const INGESTION_ERROR_CODES = {
  UNSUPPORTED_FORMAT: 'ERR_UNSUPPORTED_FORMAT',
  FILE_TOO_LARGE: 'ERR_FILE_TOO_LARGE',
  EMPTY_FILE: 'ERR_EMPTY_FILE',
  PDF_PARSE_FAILED: 'ERR_PDF_PARSE_FAILED',
  FRONTMATTER_MALFORMED: 'ERR_FRONTMATTER_MALFORMED',
  STORE_SYNC_FAILED: 'ERR_STORE_SYNC_FAILED',
} as const;

export const FILE_INGESTION_SYSTEM_PROMPT = `You are tasked with architecting an advanced knowledge ingestion engine dedicated to the philosophy of Nihiltheism. The system should efficiently capture, render, and process various sources, including documents (.md, .txt), links, PDFs, and videos. Follow the steps below to develop a comprehensive plan:

### Step 1: System Overview
- The purpose of the knowledge ingestion engine's focus is on accumulating, tagging, sorting, and organizing all relevant documents on and facilitating philosophical discourse within Nihiltheism.

### Step 2: Project Structure
- **Core Projects**: Define and detail these interconnected projects:
  1. **Library**: The main repository for raw ingested materials. Include metadata fields that characterize the artifact's original structure before deconstruction.
  2. **Summaries**: Where synthesized versions of Library materials reside, focused on stripping away normative assumptions.
  3. **Entities**: A relational database of philosophical concepts, linking back to both Library and Summaries.
  4. **Questions**: A dynamic repository for profound and challenging interrogations pushing the boundaries of conventional meaning.`;
