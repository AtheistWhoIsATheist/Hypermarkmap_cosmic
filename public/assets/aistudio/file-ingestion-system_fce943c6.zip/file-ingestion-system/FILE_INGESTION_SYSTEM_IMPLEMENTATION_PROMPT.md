# AI Implementation Prompt: Complete File Ingestion System for the Nihiltheism Knowledge Graph

## Purpose

You are being handed an already rendered Nihiltheism Knowledge Graph application. Your task is to implement, repair, complete, verify, and package a robust file ingestion system into that existing graph application without diminishing quality, omitting entities, leaving unresolved imports, skipping dependencies, or weakening the existing rendered graph.

This Markdown file is the handoff contract. It gives the receiving AI the exact implementation context, file inventory, architectural purpose, and verification requirements needed to build the file ingestion system into a standalone zip archive.

The target outcome is a complete, compiling, production-oriented ingestion system that can ingest supported documents, parse and normalize their contents, convert them into canonical AST structures, extract conceptual and ontological relations, update the PKM store, update the knowledge graph store, support summarization, expose a usable ingestion UI, and preserve export compatibility.

Do not create a separate application. Integrate this ingestion system into the existing Nihiltheism Knowledge Graph.

## Complete File Inventory for Zip Handoff

The following file paths are required to package and hand off the file ingestion system into a zip archive with zero omissions, unresolved imports, or missing dependencies.

## 1. Primary Ingestion Pipeline Modules

src/lib/ingestion/types.ts

Purpose: Canonical ingestion type system.

This file must define the core contracts required by the ingestion engine, including canonical AST node definitions, token dictionaries, relation schemas, file metadata structures, parser outputs, batch processing states, fidelity labels, and batch summary contracts.

Required entities include:

CanonicalASTNode  
CanonicalASTDocument  
CanonicalTokenDictionary  
CanonicalRelationSchema  
IngestionFile  
ParsedDocument  
DocumentMetadata  
DocumentChunk  
IngestionResult  
IngestionError  
IngestionProgress  
BatchIngestionSummary  
LayoutFidelity  
GraphNodeCandidate  
GraphEdgeCandidate  

Relation schemas must include, at minimum:

isA  
causes  
partOf  
contrastsWith  
supports  
negates  
references  
resonatesWith  

src/lib/ingestion/parser.ts

Purpose: Unified public ingestion API facade.

This file must orchestrate file format routing, stream decoding, parser selection, AST generation, normalization, and result packaging.

It should expose a stable public API used by the UI and batch processor. It must route supported file formats to the correct specialized ingestion path and reject unsupported formats with clear typed errors.

Supported minimum formats:

.md  
.txt  
.pdf  

Optional formats may be added only if fully implemented.

src/lib/ingestion/astStripper.ts

Purpose: Lossless Markdown and structured text parser.

This file must preserve meaningful philosophical content while stripping syntactic noise. It must support YAML frontmatter extraction, Markdown heading structure, block quotes, lists, code block handling where relevant, [[wikilink]] parsing, ontological relation extraction, and resonance scoring.

It must not destroy semantically meaningful quotations, headings, or conceptual relations.

src/lib/ingestion/heuristicNormalizer.ts

Purpose: Plaintext heuristic normalization pipeline.

This file must repair raw extracted text into graph-ready semantic material. It should normalize whitespace, repair broken line wrapping, restore paragraph boundaries, identify conceptual frequency signals, categorize entities, and produce normalized text suitable for chunking, summarization, and graph extraction.

src/lib/ingestion/pdfStreamReader.ts

Purpose: PDF stream extraction and layout-aware degradation handling.

This file must parse PDF content into usable text while preserving as much layout structure as feasible. It should use spatial coordinate sorting when available, mark layout fidelity as heuristic-approximate when full fidelity is impossible, and degrade gracefully when PDFs are malformed, scanned, encrypted, or structurally unstable.

It must not falsely claim lossless extraction when only heuristic extraction is available.

src/lib/ingestion/batchProcessor.ts

Purpose: Concurrent multi-file batch ingestion engine.

This file must process multiple files safely with live progress callbacks, controlled concurrency, AST compilation, failure isolation, and batch-level summaries. It must support partial success: one failed file must not collapse the entire batch unless a systemic failure occurs.

It must coordinate parser execution, normalization, AST generation, summarization, PKM handoff, and graph handoff.

It must support embedded reference corpora only if those corpora are actually present and explicitly represented in the codebase.

## 2. UI Components and Ingestion Views

src/components/BulkIngestionModal.tsx

Purpose: Full-featured ingestion user interface.

This file must provide the user-facing ingestion workflow inside the existing Nihiltheism Knowledge Graph application.

Required UI capabilities:

Drag-and-drop dropzone  
Manual file picker  
Selected file list  
Live progress indicator  
Per-file processing status  
Success count  
Failure count  
File-level layout fidelity badges  
Lossless versus heuristic extraction indicators  
Interactive AST inspector  
Error display  
One-click store commit  
Reset or close behavior  
Partial-success handling  

The component must use existing UI primitives rather than inventing a separate design system.

It must remain usable on desktop and must not break the rendered knowledge graph layout.

## 3. State and Storage Engines

src/store/pkmStore.ts

Purpose: Zustand PKM persistent store.

This file must manage ingested documents, content hashes, document metadata, normalized text, canonical ASTs, full-text indexing structures, summaries, metadata caches, and source references.

Required responsibilities:

Store ingested documents  
Detect duplicate or repeated files  
Preserve original filename and metadata  
Persist normalized text  
Persist AST output  
Persist summaries  
Maintain content hashes  
Expose selectors for document retrieval  
Synchronize ingestion results with graph updates  

src/store/graphStore.ts

Purpose: Zustand knowledge graph store.

This file must manage graph integration for ingested ontological nodes, directional tension edges, source-linked document nodes, conceptual clusters, and topology updates.

Required responsibilities:

Accept graph candidates from the ingestion pipeline  
Create document nodes  
Create concept nodes  
Create source/reference nodes  
Create directional edges  
Represent tension edges where justified  
Avoid uncontrolled duplicate graph entities  
Preserve source traceability  
Maintain cluster topology compatibility  
Avoid corrupting existing rendered graph state  

## 4. Services and Distillation Core

src/services/summarizer.ts

Purpose: Cognitive distillation and summarization client service.

This file must generate concise source-grounded summaries for ingested documents and chunks. It may use ascetic reduction heuristics, local fallback summaries, content-hash caching, and server-side proxy integration.

If server-side summarization is used, it must integrate with:

server.ts  
/api/ai/summarize  

The summarizer must not hallucinate claims unsupported by the ingested source text.

If AI summarization fails, the system must fall back to a deterministic heuristic summary rather than crashing the ingestion batch.

## 5. Constants and Specification Contracts

src/constants/file-ingestion-system.ts

Purpose: Central ingestion constants and format contracts.

This file must define supported file formats, MIME type constraints, extension rules, AST schema labels, parser limits, file size limits, fidelity labels, status labels, UI strings, error codes, chunking defaults, and ingestion defaults.

Supported file format definitions must include:

.md  
.txt  
.pdf  

Do not list a format as supported unless the pipeline can actually process it.

## 6. Verification and Test Suite

src/App.test.tsx

Purpose: System-level test suite for the ingestion flow.

This file must assert that the ingestion system works at the highest-value integration points.

Required test coverage:

Bulk ingestion modal renders  
Markdown AST parsing works  
YAML frontmatter extraction works  
Wikilink parsing works  
Plaintext normalization works  
Unsupported files are rejected safely  
PDF failure does not crash the batch  
Successful ingestion updates pkmStore.ts  
Successful ingestion updates graphStore.ts  
Store synchronization works  
Partial batch failure is recoverable  
Export receives graph-compatible data  

Tests should prove the system’s real behavior, not merely snapshot component markup.

## 7. Required Supporting Dependencies for Standalone Zip Compilation

The following files are required so the receiving environment compiles without missing import errors.

src/lib/types.ts

Purpose: Core type contracts imported by pkmStore.ts and related graph/storage modules.

Required exported contracts include:

PKMDocument  
Connection  
KnowledgeGap  

This file must remain compatible with both the existing graph system and the new ingestion pipeline.

src/lib/exportEngine.ts

Purpose: Downstream export utility.

This file must convert ingested AST graphs and knowledge graph state into exportable formats, including InfraNodus-compatible structures where required.

It must preserve provenance, source document metadata, node relationships, edge directionality, and graph structure.

lib/utils.ts

Purpose: Tailwind class-variance merge utility.

Required export:

cn  

This is used across the UI layer, including the ingestion modal and UI primitives.

components/ui/dialog.tsx

Purpose: Modal dialog primitives.

Used by:

src/components/BulkIngestionModal.tsx  

Required primitives may include:

Dialog  
DialogContent  
DialogHeader  
DialogTitle  
DialogDescription  
DialogFooter  
DialogTrigger  

components/ui/button.tsx

Purpose: Action button primitive.

Used by the ingestion modal for file selection, reset, commit, cancel, and export actions.

components/ui/badge.tsx

Purpose: Status and fidelity badge primitive.

Used for file status labels, error labels, and layout fidelity indicators such as Lossless and Heuristic.

components/ui/scroll-area.tsx

Purpose: Scrollable container primitive.

Used for AST inspection, file lists, parsing details, and long ingestion logs.

components/ui/progress.tsx

Purpose: Animated progress bar primitive.

Used during batch ingestion to show per-file and overall progress.

server.ts

Purpose: Express proxy server.

This file must provide the summarization endpoint used by summarizer.ts:

/api/ai/summarize  

The server must handle summarization requests safely, return typed responses, and fail gracefully when the upstream AI service is unavailable.

## Exact Required File Path List

FILE_INGESTION_SYSTEM_IMPLEMENTATION_PROMPT.md

src/lib/ingestion/types.ts

src/lib/ingestion/parser.ts

src/lib/ingestion/astStripper.ts

src/lib/ingestion/heuristicNormalizer.ts

src/lib/ingestion/pdfStreamReader.ts

src/lib/ingestion/batchProcessor.ts

src/components/BulkIngestionModal.tsx

src/store/pkmStore.ts

src/store/graphStore.ts

src/services/summarizer.ts

src/constants/file-ingestion-system.ts

src/App.test.tsx

src/lib/types.ts

src/lib/exportEngine.ts

lib/utils.ts

components/ui/dialog.tsx

components/ui/button.tsx

components/ui/badge.tsx

components/ui/scroll-area.tsx

components/ui/progress.tsx

server.ts

## System Workflow

The ingestion system must support this end-to-end flow:

1. The user opens BulkIngestionModal.tsx.
2. The user selects or drops supported files.
3. The modal validates file type, size, and basic constraints using constants from file-ingestion-system.ts.
4. batchProcessor.ts receives the files and begins controlled processing.
5. parser.ts routes each file to the correct parsing path.
6. astStripper.ts handles Markdown and structured text extraction.
7. heuristicNormalizer.ts cleans and normalizes extracted plaintext.
8. pdfStreamReader.ts extracts PDF text and assigns layout fidelity.
9. types.ts provides the canonical AST and ingestion contracts.
10. summarizer.ts generates source-grounded summaries or deterministic fallback summaries.
11. pkmStore.ts stores documents, metadata, hashes, summaries, ASTs, and normalized text.
12. graphStore.ts receives node and edge candidates and updates the rendered graph state.
13. BulkIngestionModal.tsx displays progress, errors, AST inspection, and completion state.
14. exportEngine.ts exports graph-compatible output with provenance preserved.
15. App.test.tsx verifies the core path and failure modes.

## Non-Negotiable Implementation Requirements

The system must be typed.

The system must compile.

The system must not rely on hidden files not listed in this handoff unless they already exist in the target application.

The system must not contain fake success states.

The system must not mark unsupported formats as supported.

The system must not silently discard parsing errors.

The system must not corrupt the existing Nihiltheism Knowledge Graph.

The system must not duplicate graph nodes uncontrollably on repeated ingestion.

The system must not hallucinate summaries or philosophical claims unsupported by source text.

The system must preserve source traceability from graph node back to ingested file.

The system must support partial batch success.

The system must expose visible, recoverable errors.

The system must keep parsing logic out of the UI component.

The system must keep UI state separate from PKM and graph persistence state.

The system must include all supporting UI primitives needed for the zip to compile.

## Deduplication Requirements

The system must detect duplicate or repeated ingestion attempts using at least one stable strategy.

Acceptable strategies include:

content hash  
normalized text hash  
filename plus file size  
existing PKM document comparison  
document ID comparison  

Duplicate handling must be explicit. The system may skip the duplicate, update the existing document, or create a clearly marked new version.

It must not silently create uncontrolled duplicate graph nodes.

## Error Handling Requirements

The system must handle the following failures:

unsupported file type  
empty file  
oversized file  
PDF parsing failure  
degraded PDF layout fidelity  
malformed Markdown frontmatter  
malformed plaintext structure  
summarization failure  
server summarization endpoint failure  
PKM store write failure  
graph store update failure  
export failure  
partial batch failure  

Every error must be typed, visible, and recoverable where possible.

## Graph Integration Requirements

Each successfully ingested file should be capable of producing:

document node  
concept nodes  
source/reference nodes  
directional relation edges  
tension edges where justified  
cluster topology updates  
source traceability links  

Graph updates must be conservative. The system should only create ontological or conceptual relations that are directly supported by extracted content or by deterministic parser rules.

Avoid fake precision.

Avoid speculative metaphysical claims.

Avoid turning every repeated word into a concept node.

## Summary and Distillation Requirements

summarizer.ts must produce summaries that are:

brief  
source-grounded  
non-hallucinatory  
cacheable by content hash  
safe to use in graph preview  
usable without AI if the server endpoint fails  

Ascetic reduction heuristics may be used, but they must reduce content responsibly rather than inventing meaning.

## Export Requirements

src/lib/exportEngine.ts must export the enriched graph and ingested content while preserving:

document metadata  
canonical AST nodes  
graph nodes  
graph edges  
source references  
content hashes  
layout fidelity labels  
summaries  
cluster information  
InfraNodus-compatible structure where required  

Exports must not erase provenance.

## Verification Contract

The task is complete only when the receiving AI can verify:

the zip contains every required file  
the app installs without unresolved imports  
TypeScript passes  
the app builds  
the ingestion modal renders  
supported Markdown files parse into canonical AST nodes  
YAML frontmatter extracts correctly  
plaintext normalization works  
PDF parsing either succeeds or fails gracefully  
batch ingestion supports partial success  
pkmStore.ts receives ingested document records  
graphStore.ts receives graph-compatible node and edge candidates  
summarizer.ts returns summaries or deterministic fallbacks  
exportEngine.ts exports ingested graph data  
App.test.tsx validates the main behavior  
existing graph functionality remains intact  

No claim of completion is valid without verification evidence.

## Final Deliverable Expected from the Receiving AI

Return a complete zip-ready implementation containing exactly the required file paths and all necessary code for the ingestion system to compile and run inside the already rendered Nihiltheism Knowledge Graph application.
