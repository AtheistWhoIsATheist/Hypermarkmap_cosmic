import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '15mb' }));

// Initialize server-side Gemini client
const getGeminiClient = (): GoogleGenAI | null => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

// Health Check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    serverAiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: Date.now(),
  });
});

// Download Ingestion System Zip
app.get(['/api/download/file-ingestion-system.zip', '/file-ingestion-system.zip'], (_req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'file-ingestion-system.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="file-ingestion-system.zip"');
  res.sendFile(zipPath);
});

// Cognitive Distillation / Summary Proxy Endpoint
app.post('/api/ai/summarize', async (req: Request, res: Response) => {
  try {
    const { filename, rawText, wordCount } = req.body;
    if (!rawText) {
      res.status(400).json({ error: 'rawText is required' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Return heuristic fallback if API key is not configured on the server
      const firstSection = rawText.slice(0, 300);
      const fallback = `### Core Ontological Thesis\nExtracted from document provenance *${filename || 'Document'}*. Structural presence manifested through ${wordCount || 0} words.\n\n### Dialectical Tensions & Antinomies\n* Primary Node: Ingested text confronting cognitive reduction.\n* Secondary Aporia: Surface linguistic signifiers resisting foundational deconstruction.\n\n### Transcendent / Practical Synthesis\n*${firstSection.trim()}...*`;
      res.json({ summaryText: fallback, isFallback: true });
      return;
    }

    const systemInstruction = `
You are the Cognitive Distillation Engine of the Nihiltheism Knowledge System (NKS).
Your purpose is Ascetic Reduction: strip all narrative bloat, redundant rhetoric, and superficial signifiers.
Formulate a dense, surgical distillation of the provided document.

Structure your response strictly in CommonMark with the following sections:
### Core Ontological Thesis
(Single dense sentence defining the groundless ground of the document)

### Dialectical Tensions & Antinomies
(Bulleted list of irreducible polar conflicts, tensions, and paradoxes)

### Transcendent / Practical Synthesis
(Concise aphoristic conclusion framing the void as presence or liberation)

DO NOT USE JSON. DO NOT INCLUDE INTRODUCTORY GREETINGS OR META-COMMENTARY.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: `${systemInstruction}\n\nDOCUMENT TITLE: ${filename || 'Untitled'}\n\nCONTENT:\n${(rawText || '').slice(0, 16000)}` },
          ],
        },
      ],
      config: {
        temperature: 0.2,
        maxOutputTokens: 1024,
      },
    });

    const summaryText = response.text || '';
    res.json({ summaryText: summaryText.trim(), isFallback: false });
  } catch (error: any) {
    console.error('Server AI Summarize error:', error);
    res.status(500).json({ error: error.message || 'Internal AI service error' });
  }
});

// Autonomous Dialectical Collision Traversal Endpoint
app.post('/api/ai/synthesize', async (req: Request, res: Response) => {
  try {
    const { docA, docB } = req.body;
    if (!docA || !docB) {
      res.status(400).json({ error: 'Both docA and docB are required' });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.json({
        title: 'Heuristic Dialectical Collision',
        thesis: `Thesis formulated from ${docA.filename}: Ontological groundlessness precedes representation.`,
        antithesis: `Antithesis formulated from ${docB.filename}: The unconditioned void functions as sacred presence.`,
        synthesis: 'Coincidentia oppositorum: Meaninglessness realized as pure unconditioned freedom.',
        tension: 0.82,
      });
      return;
    }

    const prompt = `
SYSTEM DIRECTIVE: You are Socratech Ω, an autonomous dialectical reasoner operating within the Nihiltheism Knowledge System.
Analyze the two texts provided and formulate an emergent philosophical paradox, an aporia, and a higher-order synthesis.
DO NOT USE JSON. Output ONLY in the following strict vertical key-value format:

TITLE: <Aphoristic Title of the Aporia>
THESIS: <Thesis formulated from Document A>
ANTITHESIS: <Antithesis formulated from Document B>
SYNTHESIS: <Radical Nihiltheistic aporia dwelling or reconciliation>
TENSION: <A decimal score between 0.00 and 1.00>

DOCUMENT A (${docA.filename}):
${(docA.rawText || '').slice(0, 4000)}

DOCUMENT B (${docB.filename}):
${(docB.rawText || '').slice(0, 4000)}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        temperature: 0.4,
        maxOutputTokens: 1024,
      },
    });

    const text = response.text || '';
    const lines = text.split('\n');
    let title = 'Emergent Ontological Antinomy';
    let thesis = '';
    let antithesis = '';
    let synthesis = '';
    let tension = 0.75;

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (line.startsWith('TITLE:')) title = line.replace('TITLE:', '').trim();
      else if (line.startsWith('THESIS:')) thesis = line.replace('THESIS:', '').trim();
      else if (line.startsWith('ANTITHESIS:')) antithesis = line.replace('ANTITHESIS:', '').trim();
      else if (line.startsWith('SYNTHESIS:')) synthesis = line.replace('SYNTHESIS:', '').trim();
      else if (line.startsWith('TENSION:')) tension = parseFloat(line.replace('TENSION:', '').trim()) || 0.75;
    }

    res.json({
      title,
      thesis: thesis || `Thesis formulated from ${docA.filename}`,
      antithesis: antithesis || `Antithesis formulated from ${docB.filename}`,
      synthesis: synthesis || 'Coincidentia oppositorum realized in the void.',
      tension: Math.min(1.0, Math.max(0.0, tension)),
    });
  } catch (error: any) {
    console.error('Server AI Synthesize error:', error);
    res.status(500).json({ error: error.message || 'Internal AI service error' });
  }
});

// Batch Ontological Mining Endpoint
app.post('/api/ai/mine-batch', async (req: Request, res: Response) => {
  try {
    const { filename, rawText, knownLabels = [] } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      res.json({ dslOutput: '' });
      return;
    }

    const dslPrompt = `
SYSTEM DIRECTIVE: Extract ontological nodes and dialectical edges from the text below.
STRICT RESTRICTION: DO NOT USE JSON. Output ONLY using the following DSL syntax:

NODE|<Type>|<UniqueName>|<PreciseDefinition>|<Weight 1-10>
EDGE|<SourceUniqueName>|<TargetUniqueName>|<DialecticalRelation>|<TensionScore 0.0-1.0>|<CitationExcerpt>

Types: pillar, nihilist, mystic, concept, aporia.

KNOWN EXISTING NODES:
${(knownLabels || []).slice(0, 80).join(', ')}

DOCUMENT: ${filename}
CONTENT:
${(rawText || '').slice(0, 10000)}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{ role: 'user', parts: [{ text: dslPrompt }] }],
      config: {
        temperature: 0.1,
        maxOutputTokens: 2048,
      },
    });

    res.json({ dslOutput: response.text || '' });
  } catch (error: any) {
    console.error('Server AI Mine Batch error:', error);
    res.status(500).json({ error: error.message || 'Internal AI service error' });
  }
});

// General Text Synthesis Endpoint
app.post('/api/ai/generate', async (req: Request, res: Response) => {
  try {
    const { prompt, maxTokens = 1000, temperature = 0.3 } = req.body;
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({ error: 'Server AI not configured (missing GEMINI_API_KEY)' });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        temperature,
        maxOutputTokens: maxTokens,
      },
    });

    res.json({ text: response.text || '' });
  } catch (error: any) {
    console.error('Server AI Generate error:', error);
    res.status(500).json({ error: error.message || 'Internal AI service error' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NKS Knowledge System server active on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start NKS server:', err);
  process.exit(1);
});
